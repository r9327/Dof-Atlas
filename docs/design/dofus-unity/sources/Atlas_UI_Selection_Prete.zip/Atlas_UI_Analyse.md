# Analyse des ressources DOFUS Unity pour Atlas

**Extraction confirmée** : 3 359 PNG indexés (23 planches), 10 polices TTF déclarées dans le ZIP.

**Résultat** : les vrais fichiers de textures de boutons, y compris les quatre états, sont présents dans l'extraction. Le style des fenêtres et des onglets est également identifiable.

## Familles à intégrer
- `btn_green_{normal,over,pressed,disabled}` : boutons standards verts.
- `btn_green_small_*` : petits boutons ronds verts et états sélectionnés.
- `btn_green_thin_border_*` et `darkStone_common_btn_greenLargeBorder_*` : bordures de boutons.
- `btn_yellow2_*` : boutons ronds jaunes.
- `btn_close_*`, `btn_arrow_pagination_*` : fermeture et pagination.
- `darkStone_common_btn_checkbox_*` : cases à cocher.
- `darkStone_common_bg_tab_*` et `bg_tab_selected_*` : états d'onglets.
- `window_border_*`, `darkStone_common_bg_small_border_*`, `Figma_window_*` : panneaux, bordures et ombres.
- `Figma_menuIcons_1x_*`, `Figma_menuIcons_2x_*` : navigation en 1x/2x.

## Polices détectées
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/-4435045869870345728_NotoSans-Medium.ttf | Noto Sans | Medium
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/-4521495747794385942_Lexend-Medium.ttf | Lexend | Medium
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/-5867710978426176568_Lexend-Bold.ttf | Lexend | Bold
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/-5939205684869695384_Lexend-Regular.ttf | Lexend | Regular
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/-7858745269954114878_Lexend-SemiBold.ttf | Lexend | SemiBold
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/3930793374362821129_NotInter-Regular.ttf | NotInter | Regular
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/6142697768145603737_Rowdies-Regular.ttf | Rowdies | Regular
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/7316148944391180273_Roboto-MediumItalic.ttf | Roboto | Medium Italic
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/8194171278618487780_LexendDeca-Regular.ttf | Lexend Deca | Regular
uielements_assets_all/Dofus_Data/StreamingAssets/aa/objects_type/Font/967375717210240504_LexendGiga-Regular.ttf | Lexend Giga | Regular


## Intégration conseillée
- Conserver le background de sélection de personnage déjà capturé, sans appliquer d'assombrissement global.
- Créer un thème isolé `dofus_unity` et ne modifier que la présentation, avec retour possible au thème Atlas existant.
- Utiliser les états graphiques distincts pour boutons et onglets; ne pas simplement changer la couleur d'un rectangle standard.
- Gérer les bordures extensibles correctement (9-slice quand compatible), sans étirer les coins.
- Utiliser 2x sur écrans haute densité et 1x ailleurs, chargement à la demande.
- Appliquer les mêmes tokens QSS Qt et CSS WebView, sans modifier moteurs, routes, préférences ni logique métier.
- Vérifier l'identité effective de chaque police dans les écrans avant de fixer son rôle final.
- Ne pas intégrer de ressources propriétaires au binaire/release public sans autorisation.

## Limites
Ce ZIP d'aperçus ne contient **pas** les PNG source haute définition ni les fichiers TTF eux-mêmes. Les véritables sources sont dans Documents/Atlas-Dofus-UI-Composants sur le PC de l'utilisateur. Aucun composant n'a été implanté ou testé dans Atlas.
