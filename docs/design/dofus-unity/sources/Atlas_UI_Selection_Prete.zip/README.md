# Atlas — sélection visuelle et export local

Ce kit contient **47 références UI vérifiées visuellement** dans les planches de DOFUS Unity, un aperçu et le script qui exporte leurs véritables PNG depuis ton PC.

**Procédure :** décompresser le ZIP, puis double-cliquer `LANCER_SELECTION.cmd`.
Le script ne lance pas DOFUS, ne modifie aucun fichier du jeu et ne fait aucun téléchargement.

L'archive générée sera `Documents/Atlas-UI-Selection-Originale.zip` : c'est celle à envoyer pour vérifier la qualité native, les transparences et les bordures.

Ce kit ne contient pas les PNG haute définition ni les fichiers de police. Les fichiers originaux restent sur l'ordinateur.

Fichiers :
- `Atlas_UI_Selection_Visuelle.png` : aperçu des composants retenus depuis les planches
- `Atlas_UI_Manifest_Cible.csv` : 47 identifiants et chemins exacts
- `Atlas_UI_Analyse.md` : audit et principes d'intégration
- `LANCER_SELECTION.cmd` : double-clic pour lancer le script
- `Atlas_UI_Exporter_Selection.ps1` : copie locale des PNG et création du ZIP
