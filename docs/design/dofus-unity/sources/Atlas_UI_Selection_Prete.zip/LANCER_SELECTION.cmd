@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Atlas_UI_Exporter_Selection.ps1"
echo.
echo Appuyez sur une touche pour fermer cette fenetre.
pause >nul
