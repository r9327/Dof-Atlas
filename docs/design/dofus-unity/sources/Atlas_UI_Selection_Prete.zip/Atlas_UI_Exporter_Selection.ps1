﻿# Export local cible des graphismes DOFUS Unity deja extraits.
# Ne modifie rien dans le repertoire du jeu. Ne collecte aucun fichier de police.
$ErrorActionPreference = 'Stop'
$root = Join-Path $env:USERPROFILE 'Documents\Atlas-Dofus-UI-Composants'
$dest = Join-Path $env:USERPROFILE 'Documents\Atlas-Dofus-UI-Selection'
$manifest = Join-Path $PSScriptRoot 'Atlas_UI_Manifest_Cible.csv'
if (-not (Test-Path -LiteralPath $manifest)) { throw 'Manifeste introuvable a cote du script' }
if (-not (Test-Path -LiteralPath $root)) { throw "Dossier source introuvable: $root" }
New-Item -ItemType Directory -Path $dest -Force | Out-Null
$rows = Import-Csv -LiteralPath $manifest -Delimiter ';' -Encoding UTF8
$ok = 0; $missing = @()
foreach ($row in $rows) {
    $src = Join-Path $root ($row.source_path -replace '/', '\')
    if (-not (Test-Path -LiteralPath $src -PathType Leaf)) {
        $missing += $row.source_path
        continue
    }
    $category = ($row.group -replace '[^a-zA-Z0-9 -]', '') -replace ' ', '_'
    $folder = Join-Path $dest $category
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    $basename = "{0}_{1}" -f $row.source_number, $row.name
    Copy-Item -LiteralPath $src -Destination (Join-Path $folder $basename) -Force
    $ok++
}
Copy-Item -LiteralPath $manifest -Destination (Join-Path $dest 'manifest.csv') -Force
$missing | Set-Content -LiteralPath (Join-Path $dest 'manquants.txt') -Encoding UTF8
$zip = Join-Path $env:USERPROFILE 'Documents\Atlas-UI-Selection-Originale.zip'
if ($ok -eq 0) { throw "Aucune image trouvee. Verifier le dossier: $root" }
Compress-Archive -Path (Join-Path $dest '*') -DestinationPath $zip -CompressionLevel Optimal -Force
Write-Host "Images copiees : $ok / $($rows.Count)" -ForegroundColor Green
Write-Host "Introuvables : $($missing.Count)" -ForegroundColor Yellow
Write-Host "Archive a envoyer : $zip" -ForegroundColor Cyan
explorer.exe /select,$zip
