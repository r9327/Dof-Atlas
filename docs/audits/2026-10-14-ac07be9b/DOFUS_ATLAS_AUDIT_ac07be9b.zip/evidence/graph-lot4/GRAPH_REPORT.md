# Graph Report - Dof-Atlas  (2026-10-13)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 12612 nodes · 36404 edges · 482 communities (288 shown, 194 thin omitted)
- Extraction: 94% EXTRACTED · 6% INFERRED · 0% AMBIGUOUS · INFERRED: 2092 edges (avg confidence: 0.91)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `8d65f506`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- Community 0
- Community 1
- Community 2
- Community 3
- Community 4
- Community 5
- Community 6
- Community 7
- Community 8
- Community 9
- Community 10
- Community 11
- Community 12
- Community 13
- Community 14
- Community 15
- Community 16
- Community 17
- Community 18
- Community 19
- Community 20
- Community 21
- Community 22
- Community 23
- Community 24
- Community 25
- Community 26
- Community 27
- Community 28
- Community 29
- Community 30
- Community 31
- Community 32
- Community 33
- Community 34
- Community 35
- Community 36
- Community 37
- Community 38
- Community 39
- Community 40
- Community 41
- Community 42
- Community 43
- Community 44
- Community 45
- Community 46
- Community 47
- Community 48
- Community 49
- Community 50
- Community 51
- Community 52
- Community 53
- Community 54
- Community 55
- Community 56
- Community 57
- Community 58
- Community 59
- Community 60
- Community 61
- Community 62
- Community 63
- Community 64
- Community 65
- Community 66
- Community 67
- Community 68
- Community 69
- Community 70
- Community 71
- Community 72
- Community 73
- Community 74
- Community 75
- Community 76
- Community 77
- Community 78
- Community 79
- Community 80
- Community 81
- Community 82
- Community 83
- Community 84
- Community 85
- Community 86
- Community 87
- Community 88
- Community 89
- Community 90
- Community 91
- Community 92
- Community 93
- Community 94
- Community 95
- Community 96
- Community 97
- Community 98
- Community 99
- Community 100
- Community 101
- Community 102
- Community 103
- Community 104
- Community 105
- Community 106
- Community 107
- Community 108
- Community 109
- Community 110
- Community 111
- Community 112
- Community 113
- Community 114
- Community 115
- Community 116
- Community 117
- Community 118
- Community 119
- Community 120
- Community 121
- Community 122
- Community 123
- Community 124
- Community 125
- Community 126
- Community 127
- Community 128
- Community 129
- Community 130
- Community 131
- Community 132
- Community 133
- Community 134
- Community 135
- Community 136
- Community 137
- Community 138
- Community 139
- Community 140
- Community 141
- Community 142
- Community 143
- Community 144
- Community 145
- Community 146
- Community 147
- Community 148
- Community 149
- Community 150
- Community 151
- Community 152
- Community 153
- Community 154
- Community 155
- Community 156
- Community 157
- Community 158
- Community 159
- Community 160
- Community 161
- Community 162
- Community 163
- Community 164
- Community 165
- Community 166
- Community 167
- Community 168
- Community 169
- Community 170
- Community 171
- Community 172
- Community 173
- Community 174
- Community 175
- Community 176
- Community 177
- Community 178
- Community 179
- Community 180
- Community 181
- Community 182
- Community 183
- Community 184
- Community 185
- Community 186
- Community 187
- Community 188
- Community 189
- Community 190
- Community 191
- Community 192
- Community 193
- Community 194
- Community 195
- Community 196
- Community 197
- Community 198
- Community 199
- Community 200
- Community 201
- Community 202
- Community 203
- Community 204
- Community 205
- Community 206
- Community 207
- Community 208
- Community 209
- Community 210
- Community 211
- Community 212
- Community 213
- Community 214
- Community 215
- Community 216
- Community 217
- Community 218
- Community 219
- Community 220
- Community 221
- Community 222
- Community 223
- Community 224
- Community 225
- Community 226
- Community 227
- Community 228
- Community 229
- Community 230
- Community 231
- Community 232
- Community 233
- Community 234
- Community 235
- Community 236
- Community 237
- Community 238
- Community 239
- Community 240
- Community 241
- Community 242
- Community 243
- Community 244
- Community 245
- Community 246
- Community 247
- Community 248
- Community 249
- Community 250
- Community 251
- Community 252
- Community 253
- Community 254
- Community 255
- Community 256
- Community 257
- Community 258
- Community 259
- Community 260
- Community 261
- Community 262
- Community 263
- Community 264
- Community 265
- Community 266
- Community 267
- Community 268
- Community 269
- Community 270
- Community 271
- Community 272
- Community 273
- Community 274
- Community 275
- Community 276
- Community 277
- Community 278
- Community 279
- Community 280
- Community 281
- Community 282
- Community 283
- Community 284
- Community 285
- Community 286
- Community 287
- Community 288
- Community 289
- Community 290
- Community 291
- Community 292
- Community 293
- Community 294
- Community 295
- Community 296
- Community 297
- Community 298
- Community 299
- Community 300
- Community 301
- Community 302
- Community 303
- Community 304
- Community 305
- Community 306
- Community 307
- Community 308
- Community 309
- Community 310
- Community 311
- Community 312
- Community 313
- Community 314
- Community 315
- Community 316
- Community 317
- Community 318
- Community 319
- Community 320
- Community 321
- Community 322
- Community 323
- Community 325
- Community 326
- Community 327
- Community 328
- Community 329
- Community 330
- Community 331
- Community 332
- Community 333
- Community 334
- Community 335
- Community 336
- Community 337
- Community 338
- Community 339
- Community 340
- Community 341
- Community 342
- Community 343
- Community 344
- Community 345
- Community 346
- Community 347
- Community 348
- Community 349
- Community 350
- Community 351
- Community 352
- Community 353
- Community 354
- Community 355
- Community 356
- Community 357
- Community 358
- Community 359
- Community 360
- Community 361
- Community 362
- Community 363
- Community 364
- Community 365
- Community 366
- Community 367
- Community 368
- Community 369
- Community 370
- Community 371
- Community 372
- Community 373
- Community 374
- Community 375
- Community 376
- Community 377
- Community 378
- Community 379
- Community 380
- Community 381
- Community 382
- Community 383
- Community 384
- Community 385
- Community 386
- Community 387
- Community 388
- Community 389
- Community 390
- Community 391
- Community 392
- Community 393
- Community 394
- Community 395
- Community 396
- Community 397
- Community 398
- Community 399
- Community 400
- Community 401
- Community 402
- Community 403
- Community 404
- Community 405
- Community 406
- Community 407
- Community 408
- Community 409
- Community 410
- Community 411
- Community 412
- Community 413
- Community 414
- Community 415
- Community 416
- Community 417
- Community 419
- Community 420
- Community 421
- Community 422
- Community 423
- Community 424
- Community 425
- Community 426
- Community 427
- Community 428
- Community 429
- Community 430
- Community 431
- Community 432
- Community 433
- Community 434
- Community 435
- Community 436
- Community 437
- Community 438
- Community 439
- Community 440
- Community 441
- Community 445
- Community 446
- Community 447
- Community 448
- Community 449
- Community 450
- Community 451
- Community 452
- Community 453
- Community 454
- Community 455
- Community 456
- Community 457
- Community 458
- Community 459
- Community 460
- Community 461
- Community 462
- Community 463
- Community 464
- Community 465
- Community 466
- Community 467
- Community 468
- Community 474

## God Nodes (most connected - your core abstractions)
1. `normalize_text()` - 193 edges
2. `CapturedProtocolMessage` - 192 edges
3. `QuestCatalog` - 184 edges
4. `QuestRecord` - 176 edges
5. `load_manual_chapter()` - 158 edges
6. `QuestProgressService` - 157 edges
7. `GuidesView` - 139 edges
8. `AtlasWindow` - 137 edges
9. `Guide` - 111 edges
10. `QuestProvider` - 100 edges

## Surprising Connections (you probably didn't know these)
- `__init__()` --indirect_call--> `catalog()`  [INFERRED]
  tests/test_startup_resource_contracts.py → tools/tool_catalog.py
- `observed_slot()` --indirect_call--> `source()`  [INFERRED]
  tools/atlas_doctor_lib/runtime_observation.py → tests/test_doctor_certification.py
- `record()` --indirect_call--> `source()`  [INFERRED]
  tools/atlas_doctor_lib/runtime_observation.py → tests/test_doctor_certification.py
- `_quest_name_index()` --uses--> `QuestProvider`  [INFERRED]
  tools/audit_guide_ultime_support_routes.py → app/modules/encyclopedia/providers/quest_provider.py
- `AtlasWindow` --uses--> `AtlasButton`  [INFERRED]
  main.py → app/ui/components.py

## Import Cycles
- None detected.

## Communities (482 total, 194 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.03
Nodes (19): CommandEvidenceTests, _PassingProbe, _HotkeyWindowMixin, CharacterPySideDiagnosticsTests, ConstantsImportSideEffectsTests, WorkflowContractTests, EncyclopediaCharacterSyncDedupeTests, GuidePlayerContractRunnerTests (+11 more)

### Community 1 - "Community 1"
Cohesion: 0.03
Nodes (37): log_uncaught_exception(), AchievementProvider, __getattr__(), GuideProvider, QuestProvider, quest_solution_blocks(), quest_start_info(), build_related_encyclopedia_data() (+29 more)

### Community 2 - "Community 2"
Cohesion: 0.02
Nodes (40): get_runtime_logger(), _runtime_formatter(), set_debug_logging(), build_windows_network_runtime(), _disabled_selection(), _is_sha256(), NetworkBootstrapResult, CaptureIpcDisconnected (+32 more)

### Community 3 - "Community 3"
Cohesion: 0.03
Nodes (55): _characteristic_container_value(), _signed_int64(), _singular_signed_scalar(), CorrelatedCharacterIdentityDecoder, CorrelatedCharacterIdentityRule, _is_sha256(), _MutableTypeDiagnostic, protocol_payload_scalar_samples() (+47 more)

### Community 4 - "Community 4"
Cohesion: 0.02
Nodes (54): _apply_stage_patch(), _expand_route_hooks(), _insert_anchored_stage(), load_manual_chapter(), _load_manual_chapter_uncached(), _merge_sequence(), _read_json(), _route_file_path() (+46 more)

### Community 5 - "Community 5"
Cohesion: 0.04
Nodes (64): item_id(), read_json_resilient(), normalize_key(), parse_unit_ratio(), read_zaap_button_ratios(), zaap_ratios_from_payload(), build_compact_craft_preload(), main() (+56 more)

### Community 6 - "Community 6"
Cohesion: 0.05
Nodes (26): AchievementCompletedEvent, AchievementObjectiveCompletedEvent, CharacterIdentifiedEvent, FinishedQuestsSnapshotEvent, NetworkEvent, QuestCompletedEvent, QuestJournalSnapshotEvent, QuestObjectiveCompletedEvent (+18 more)

### Community 7 - "Community 7"
Cohesion: 0.04
Nodes (15): NetworkApplicationCoordinator, NetworkApplicationStatus, ProtocolCalibrationControllerStatus, NetworkUiBridge, refresh_visible_encyclopedia_widgets(), _AutoCalibrationFake, _CalibrationFake, _EncyclopediaFake (+7 more)

### Community 8 - "Community 8"
Cohesion: 0.06
Nodes (27): clean_auto_group_name(), CharacterSessionsMixin, class_icon_candidates(), class_icon_path_for_window_name(), client_slot_hotkey_key(), dofus_class_key_for_character_name(), dofus_class_key_from_window_name(), empty_session_slot() (+19 more)

### Community 9 - "Community 9"
Cohesion: 0.04
Nodes (13): _empty_progress(), load_quest_progress(), QuestProgressService, AchievementLot7QuestSyncTests, PerformanceGuardTests, ProgressConcurrentInstanceTests, _mutate_quest(), ProgressMultiInstanceTests (+5 more)

### Community 10 - "Community 10"
Cohesion: 0.04
Nodes (21): build_windows_protocol_calibration(), _is_sha256(), ProtocolCalibrationBootstrapResult, ProtocolCalibrationController, ProtocolCalibrationRuntime, ProtocolMappingInstallResult, ProtocolCalibrationStatus, QuestAchievementSeries (+13 more)

### Community 11 - "Community 11"
Cohesion: 0.05
Nodes (23): GuideProgressCalculator, QuestObjective, QuestRecord, QuestReward, QuestSolutionBlock, QuestStep, AchievementContextPhase2Tests, EncyclopediaOnDemandTests (+15 more)

### Community 12 - "Community 12"
Cohesion: 0.05
Nodes (23): _candidate_achievement_snapshot(), _candidate_character_stats(), _candidate_level(), CharacterRuntimeProtocolMessageDecoder, _expected_characteristic_container(), CharacterRuntimeSnapshot, CharacterRuntimeStateStore, _achievements_payload() (+15 more)

### Community 13 - "Community 13"
Cohesion: 0.05
Nodes (19): Achievement, _achievement_compact_cache_valid(), _achievement_compact_index_path(), _achievement_compact_source_signature(), _achievement_from_dict(), _build_compact_cache(), _compact_achievement_dict(), _compact_objective_dict() (+11 more)

### Community 14 - "Community 14"
Cohesion: 0.06
Nodes (6): AtlasPageTitle, AtlasWindow, _resolve_encyclopedia_page(), _resolve_equipment_page(), _resolve_organizer_page(), AtlasWindowRuntimeCleanupTests

### Community 15 - "Community 15"
Cohesion: 0.04
Nodes (21): __getattr__(), GuideUltimeManualRuntimeService, apply_player_line_policy(), ensure_drop_purchase_alternative(), has_actionable_drop(), _has_player_action(), has_purchase_alternative(), _is_consequence_boundary() (+13 more)

### Community 16 - "Community 16"
Cohesion: 0.05
Nodes (24): strip_accents(), DofusItemProvider, _dump_compact_default_items(), PathProfile, achievement_row(), build_audit(), file_evidence(), main() (+16 more)

### Community 17 - "Community 17"
Cohesion: 0.07
Nodes (40): empty_summary(), import_map_view_manifest(), load_manifest(), validate_manifest(), get_map_status(), get_status_color(), mark_unverified(), mark_verified() (+32 more)

### Community 18 - "Community 18"
Cohesion: 0.06
Nodes (58): ProgressCount, DisplaySolutionBlock, activity_chip_grid(), activity_icon_key(), activity_labels(), atlas_icon(), _catalog_subtitle(), clean_requirement_line() (+50 more)

### Community 19 - "Community 19"
Cohesion: 0.06
Nodes (5): clear_layout(), GuidesView, restore_side_scrolls(), _single_shot(), test_external_signature_compares_all_progress_sources_and_character()

### Community 20 - "Community 20"
Cohesion: 0.06
Nodes (28): key(), _env_truthy(), network_debug_enabled(), network_debug_log(), protocol_payload_summary(), _safe_debug_value(), DiagnosticProtocolMessageDecoder, InstrumentedCurrentProtocolCalibration (+20 more)

### Community 21 - "Community 21"
Cohesion: 0.06
Nodes (18): baseline_keys(), format_unexpected(), legacy_import_violations(), _module_is_legacy(), parse_source(), _qualified_name(), read_source(), _root_name() (+10 more)

### Community 22 - "Community 22"
Cohesion: 0.05
Nodes (8): _achievement_detail_widget_type(), _achievement_entity_row_type(), _AchievementListRef, AchievementsView, _alignment_guide_ids(), _alignment_order_achievement_ranks(), _order_quest_ids(), AchievementLot7AlignmentTests

### Community 23 - "Community 23"
Cohesion: 0.08
Nodes (30): ensure_directories(), LocalDataConfig, D2IImporter, ExistingCacheImporter, decode_row(), export_all(), main(), ImageIndexer (+22 more)

### Community 24 - "Community 24"
Cohesion: 0.04
Nodes (17): CharacterResolution, CharacterSlotResolver, QuestCharacter, CharacterPidOwnershipTests, CharacterShellCanonicalTests, character_icon_path(), _ensure_runtime(), __init__() (+9 more)

### Community 25 - "Community 25"
Cohesion: 0.05
Nodes (11): HotkeyAction, HotkeyReport, InputState, SyntheticInputGuard, ManagedHotkeyRegistry, ManagedMouseHook, MouseHook, startup_flush() (+3 more)

### Community 26 - "Community 26"
Cohesion: 0.08
Nodes (8): EncyclopediaPage, worker(), _has_embedded_search(), _is_achievements_view(), _is_guides_view(), _QuestRuntimePayload, _resolve_achievements_view_type(), _resolve_guide_catalog_view_type()

### Community 27 - "Community 27"
Cohesion: 0.08
Nodes (16): GuideUltimeManualRuntimeService, fingerprint(), player_line(), player_value(), remember(), _manual_bundle_cache_key(), _manual_bundle_catalog_signature(), _manual_bundle_snapshot() (+8 more)

### Community 28 - "Community 28"
Cohesion: 0.06
Nodes (14): _cancel_pending_future(), _catalog_guide_title(), _decode_solution_image(), DofusGuideGrid, GuideHomeCard, _progress_label(), SolutionImageLabel, _tuple_progress_state() (+6 more)

### Community 29 - "Community 29"
Cohesion: 0.05
Nodes (17): QuestViewContext, QuestsPage, check_environment(), compile_script(), _elapsed_ms(), main(), GuideToolsCliTests, GuideToolsDoctorTests (+9 more)

### Community 30 - "Community 30"
Cohesion: 0.07
Nodes (27): build_craft_list(), craft_category_for_item(), decorate_craft_items(), get_adapter(), get_cached_image_path(), get_item(), get_item_by_name(), get_item_image() (+19 more)

### Community 31 - "Community 31"
Cohesion: 0.06
Nodes (19): _cache_identity(), _connect(), DeferredQuestRecord, ensure_lazy_catalog_cache(), _guide_evidence_index(), _json(), load_lazy_catalog(), load_network_catalog() (+11 more)

### Community 32 - "Community 32"
Cohesion: 0.10
Nodes (52): array_from_any(), base_enriched_quest(), block_to_json(), build_mapping(), build_parser(), clean_duffus_step_text(), clean_text(), collect_prerequisite_metadata_line() (+44 more)

### Community 33 - "Community 33"
Cohesion: 0.09
Nodes (33): SwitchCharacterMacro, run(), SwitchClickContext, SwitchClickMacro, current_cursor_pos(), INPUT, INPUT_UNION, MOUSEINPUT (+25 more)

### Community 34 - "Community 34"
Cohesion: 0.12
Nodes (48): DoctorUiCaptureContracts, _audit(), build_parser(), command_all(), command_audit(), command_capabilities(), command_capture_ui(), command_certification() (+40 more)

### Community 35 - "Community 35"
Cohesion: 0.06
Nodes (13): DeepIntelligenceTests, architectural_guardrails(), graph_reachability(), inspect_code(), launcher_entrypoints(), _missing_internal_imports(), _relative(), scan_sources() (+5 more)

### Community 36 - "Community 36"
Cohesion: 0.09
Nodes (45): achievement_quest_series(), achievements_by_quest(), add_unique(), apply_quest_enrichment(), array_value(), _catalog_from_cache_payload(), _catalog_to_cache_payload(), criteria_to_lines() (+37 more)

### Community 37 - "Community 37"
Cohesion: 0.07
Nodes (15): _copy_identity(), _copy_step_validated(), dofus_361010_candidate_manifest(), dofus_361010_candidate_mapping_payload(), dofus_361010_profile_digest(), _is_current_type_url(), _is_sha256(), ReviewedProtocolProfile (+7 more)

### Community 38 - "Community 38"
Cohesion: 0.08
Nodes (3): DoctorGraphUiTests, compact_graph(), render_html()

### Community 39 - "Community 39"
Cohesion: 0.06
Nodes (46): MemoryPolicyContractUnittest, test_achievement_provider_releases_reconstructible_source_maps(), test_achievement_sync_uses_compact_alignment_guide_ids(), test_atlas_manual_guide_disables_bundle_copy_and_wrapper_duplicate_snapshots(), test_background_related_preload_keeps_runtime_imports_out_of_parent(), test_craft_preload_and_runtime_are_sqlite_bounded(), test_disk_only_preload_does_not_import_home_encyclopedia_runtime(), test_dofus_item_extraction_does_not_parse_monolithic_sources_in_parent() (+38 more)

### Community 40 - "Community 40"
Cohesion: 0.04
Nodes (8): RelatedPreloadGate, RelatedPreloadState, FaultInjectionContractsTests, catalog_fixture(), LazyQuestsPagePerformanceTests, run_thread(), quest(), RelatedPreloadStateTests

### Community 42 - "Community 42"
Cohesion: 0.10
Nodes (15): safe_int(), _collect_guide_item_ids(), walk(), _first_int(), GuideProvider, visit(), add_achievement(), matches() (+7 more)

### Community 43 - "Community 43"
Cohesion: 0.06
Nodes (21): __getattr__(), _BpfProgram, _decode_error(), _ipv4_addresses(), ipv4_packet_from_link_frame(), NpcapCaptureError, _NpcapCaptureHandle, _NpcapDevice (+13 more)

### Community 44 - "Community 44"
Cohesion: 0.07
Nodes (16): Guide, _drop_nested_raw(), _build_compact_guide_cache(), _CompactGuideNoopItemProvider, _dump_compact_default_guides(), _ensure_compact_guide_cache_cli(), ensure_guide_compact_cache(), _entity_index_payload() (+8 more)

### Community 45 - "Community 45"
Cohesion: 0.09
Nodes (28): _achievement_index(), _achievement_index_from_loaded_provider(), _achievement_provider_signature(), _aggregate_quantity_targets(), build_card_auto_validation_contract(), build_route_auto_validation_contract(), _build_route_auto_validation_contract_uncached(), _dungeon_name() (+20 more)

### Community 46 - "Community 46"
Cohesion: 0.11
Nodes (32): _planning_catalog(), cache_matches_git(), git_state(), _json_path(), load_json(), project_root(), runtime_dir(), utc_now() (+24 more)

### Community 47 - "Community 47"
Cohesion: 0.09
Nodes (14): BaseRepository, _decode_json_fields(), ImageRepository, ItemRepository, ItemSetRepository, JobRepository, _legacy_image_url_or_path(), _legacy_item() (+6 more)

### Community 48 - "Community 48"
Cohesion: 0.06
Nodes (14): character_id_from_key(), character_key(), is_character_key(), _AchievementStagePayload, worker(), binding_schema_error(), merge_verified_binding_classes(), read_binding_payload() (+6 more)

### Community 49 - "Community 49"
Cohesion: 0.08
Nodes (28): CurrentProtocolCalibration, _PendingJournalState, _positive_int(), QuestJournalCalibrationEvidence, _SessionCalibrationState, _b(), _CalibrationFake, _idr() (+20 more)

### Community 50 - "Community 50"
Cohesion: 0.10
Nodes (33): _capture(), _descendant_rows(), main(), measure(), memory_snapshot(), _open_guide_with_probe(), _open_rich_guide_with_probe(), probed_manual_loader() (+25 more)

### Community 51 - "Community 51"
Cohesion: 0.09
Nodes (23): classify_domains(), fingerprint(), historical_evidence_usable(), plan(), _required_boundary_modules(), _safe_paths(), verify_scoped_evidence(), _git() (+15 more)

### Community 52 - "Community 52"
Cohesion: 0.07
Nodes (12): _cached_mandatory_references(), parse(), split_top(), strip_outer(), GuidePathResolver, walk(), walk(), build_one() (+4 more)

### Community 53 - "Community 53"
Cohesion: 0.11
Nodes (26): _is_ankama_type_url(), _is_sha256(), load_protocol_mapping(), _non_negative_int(), _parse_character_identity(), _parse_finished_quests_snapshot(), _parse_path(), parse_protocol_mapping() (+18 more)

### Community 54 - "Community 54"
Cohesion: 0.10
Nodes (23): fixture(), GraphIntelligenceTests, analyze_community_boundaries(), _candidate_symbol(), compare_graphs(), complete_cycles(), _components(), correlate_performance() (+15 more)

### Community 55 - "Community 55"
Cohesion: 0.06
Nodes (17): _expected(), _full(), GuideExactFullEvidenceTests, FullSuiteStructuredReuseTests, passing(), GuideCriterionScopeBoundaryTests, canonical(), ids() (+9 more)

### Community 56 - "Community 56"
Cohesion: 0.09
Nodes (25): GuideUltimeCanonicalDependenciesTests, GuideUltimeCanonicalLockTests, audit(), _audit_critical_supports(), _dependency_files(), _load(), main(), _manifest_support_files() (+17 more)

### Community 57 - "Community 57"
Cohesion: 0.08
Nodes (14): AchievementObjective, EntityRef, Reward, _entity_ref_from_dict(), _entity_refs_from_rows(), _objective_from_dict(), _reward_from_dict(), _entity_ref_payload() (+6 more)

### Community 58 - "Community 58"
Cohesion: 0.07
Nodes (24): build_report(), documentary_text_count(), legacy_visual_count(), main(), markdown_report(), read_json(), build_audit(), enriched_visual_rows() (+16 more)

### Community 59 - "Community 59"
Cohesion: 0.09
Nodes (32): activity_flags(), audit_live_page(), base_result(), build_audit(), inspect(), clean_tokens(), compare_images(), compare_objects() (+24 more)

### Community 60 - "Community 60"
Cohesion: 0.08
Nodes (25): result(), VerifiedMainFullReuseTests, IndependentAuthorityTests, protected(), same_blobs(), event(), jobs(), MainPhaseEvidenceTests (+17 more)

### Community 61 - "Community 61"
Cohesion: 0.09
Nodes (45): activity_labels(), _add_unique_line(), clean_requirement_line(), _clean_solution_instruction_text(), clean_text(), _count_label(), DisplayItem, _drop_preparation_label() (+37 more)

### Community 62 - "Community 62"
Cohesion: 0.10
Nodes (6): GuideUltimeGeneratedService, GuideUltimeProgress, _norm(), _read_json(), _safe_int(), GuideUltimeLazyFallbackTests

### Community 63 - "Community 63"
Cohesion: 0.16
Nodes (34): _add_typed_item(), _bool_or_none(), bundle_from_records(), classify_item(), empty_bundle(), merge_bundles(), normalize_api_item(), normalize_class_spell_links() (+26 more)

### Community 64 - "Community 64"
Cohesion: 0.11
Nodes (16): backup_corrupt_json(), InvalidPersistentJsonError, _is_shared_profile_path(), read_json_validated(), _reject_persistent_json(), _same_path(), write_json_atomic(), _write_json_atomic_unchecked() (+8 more)

### Community 65 - "Community 65"
Cohesion: 0.07
Nodes (5): GuideUltimeManualCard, GuideManualContractRowCacheTests, _Service, GuideUltimeManualClickableEntityTests, _QuestProvider

### Community 66 - "Community 66"
Cohesion: 0.10
Nodes (15): ProtocolFieldRule, ProtocolMessageRule, StrictMappedProtocolDecoder, QuestJournalRule, NetworkAuditRegressionTests, encode_varint(), NetworkMappedDecoderTests, varint_field() (+7 more)

### Community 68 - "Community 68"
Cohesion: 0.16
Nodes (39): AgentConfigError, _anchor_specificity(), _declared_ownership_conflicts(), doctor_payload(), _git(), impact_payload(), _import_from_module(), imports_payload() (+31 more)

### Community 70 - "Community 70"
Cohesion: 0.11
Nodes (31): flags_from_text(), interaction_from_text(), portable_asset_path(), actionable_images(), actionable_rows(), block_content_key(), block_source_url(), build_parser() (+23 more)

### Community 71 - "Community 71"
Cohesion: 0.08
Nodes (7): DataStore, migration_for(), CompatibilityAdapterTests, DataStoreBackupTests, DataStoreTests, DataStoreMigrationTests, RepositoryTests

### Community 72 - "Community 72"
Cohesion: 0.13
Nodes (16): _array(), _coord_from_text(), DocumentaryIndex, _explicit_coord(), ForensicAudit, _iter_action_rows(), _iter_final_steps(), main() (+8 more)

### Community 73 - "Community 73"
Cohesion: 0.07
Nodes (4): AtlasIntegrityGateTests, run(), run(), FakeExecutor

### Community 74 - "Community 74"
Cohesion: 0.09
Nodes (16): AdminAudit, audit_client_admin_rights(), current_process_is_admin(), process_id_for_window(), process_is_elevated(), TOKEN_ELEVATION, main(), _preferred_capture_source() (+8 more)

### Community 75 - "Community 75"
Cohesion: 0.10
Nodes (6): require_character_key(), AchievementProgressService, _empty_progress(), AchievementProgressConcurrentInstanceTests, AchievementProgressJsonStoreTests, CharacterWriteBoundaryTests

### Community 76 - "Community 76"
Cohesion: 0.11
Nodes (12): AdventureRouteEngine, visit(), ItemRequirement, _norm(), OptimizationMetrics, OptimizationWeights, RouteAction, RouteLocation (+4 more)

### Community 77 - "Community 77"
Cohesion: 0.15
Nodes (3): GuideUltimeManualConditionsMixin, _manual_card_static_key(), normalize_text()

### Community 78 - "Community 78"
Cohesion: 0.12
Nodes (27): load_temporal_registry(), _merge_dict(), _read(), GuideUltimeOcreTemporalLockTests, GuideUltimeTemporalRegistryTests, audit(), _before(), _canonical_rows() (+19 more)

### Community 79 - "Community 79"
Cohesion: 0.13
Nodes (38): append_issue_table(), audit_graph(), audit_guides(), audit_images(), audit_progress(), audit_quests(), build_audit(), dir_entry() (+30 more)

### Community 80 - "Community 80"
Cohesion: 0.11
Nodes (23): ActiveProtocolBuildFingerprintProvider, _CachedFingerprint, _file_signature(), process_executable_path(), protocol_build_files_for_executable(), protocol_build_sha256(), ProtocolBuildFiles, build_parser() (+15 more)

### Community 81 - "Community 81"
Cohesion: 0.12
Nodes (32): module_proofs(), affected_groups(), build_diff_report(), changed_files(), _changed_test_modules(), classify_risk(), _command_for_group(), CommandExecutor (+24 more)

### Community 82 - "Community 82"
Cohesion: 0.12
Nodes (27): build_cache_from_providers(), filter_entries_for_world(), get_cache_summary(), get_local_image_files(), get_local_image_stats(), is_default_world_entry(), LocalImageStats, MapCacheSummary (+19 more)

### Community 83 - "Community 83"
Cohesion: 0.09
Nodes (7): _empty_progress(), GuideProgressService, read_json_resilient(), GuideProgressManualCacheTests, GuideProgressPersistenceTests, CharacterIdProgressStorageTests, ProgressMutationIdempotenceTests

### Community 84 - "Community 84"
Cohesion: 0.08
Nodes (7): AtlasRuntime, AutoGroupMacro, TravelMacro, test_runtime_constructor_does_not_load_settings(), fake_load_settings(), test_runtime_settings_injection_does_not_trigger_disk_load(), test_runtime_settings_load_once_on_first_access()

### Community 85 - "Community 85"
Cohesion: 0.10
Nodes (21): _combine_and(), criterion_alternatives(), walk(), CriterionAlternative, CriterionAtom, mandatory_qf_ids(), qf_alternative_sets(), residual_qf_alternatives() (+13 more)

### Community 86 - "Community 86"
Cohesion: 0.10
Nodes (10): _TrackedFlow, WindowsTcpFlow, FramedProtocolMessage, ProtobufAnyStreamDecoder, TcpStreamReassembler, any_envelope(), any_envelope_header(), encode_varint() (+2 more)

### Community 87 - "Community 87"
Cohesion: 0.09
Nodes (3): craft_category_for_item(), CraftPage, CraftMinimalLazyTests

### Community 88 - "Community 88"
Cohesion: 0.06
Nodes (6): CaptureIpcError, FramedJsonConnection, FakeHelperLauncher, worker(), NetworkElevatedCaptureTests, __init__()

### Community 89 - "Community 89"
Cohesion: 0.13
Nodes (19): build_parser(), load_report(), main(), build_discovery_consensus(), _is_capture_id(), _is_sha256(), _non_negative_int(), parse_discovery_consensus() (+11 more)

### Community 90 - "Community 90"
Cohesion: 0.17
Nodes (33): AssetValidation, check_doduda_release_archive(), copy_asset_to_expected_path(), download_file(), expected_world_assets(), ExpectedWorldAsset, extract_matching_worldmap_archive(), find_doduda_executable() (+25 more)

### Community 91 - "Community 91"
Cohesion: 0.08
Nodes (4): DeferredEncyclopediaSmokeTests, RuntimeObservationTests, compare_runtime_to_graph(), RuntimeObserver

### Community 93 - "Community 93"
Cohesion: 0.12
Nodes (20): default_profiles(), parse_unit_ratio(), parse_zaap_click_position(), profile_bool(), read_zaap_button_ratios(), assert_zaap_timings_unchanged(), AtlasClient, AtlasSettings (+12 more)

### Community 94 - "Community 94"
Cohesion: 0.11
Nodes (6): AchievementCategory, AchievementProvider, achievement_sort_key(), resolve_links(), source_position(), replace()

### Community 95 - "Community 95"
Cohesion: 0.13
Nodes (30): full_url(), skip_dpln_text(), source_title_key(), useful_image(), ordered_metadata(), build_verification(), candidate_urls(), canonical_slug() (+22 more)

### Community 96 - "Community 96"
Cohesion: 0.11
Nodes (15): build_parser(), load_consensus(), main(), validate_consensus_deobfuscation(), validate_consensus_deobfuscation_reports(), ankama_type_alias(), DeobfuscationMatch, DeobfuscationReport (+7 more)

### Community 97 - "Community 97"
Cohesion: 0.14
Nodes (7): KnownSessionProgressBridge, KnownSessionProtocolMessageDecoder, _positive_int(), _trusted_client_label(), VerifiedKnownSessionRecovery, _DecoderDelegate, KnownSessionRecoveryTests

### Community 98 - "Community 98"
Cohesion: 0.09
Nodes (12): build_parser(), install_verified_protocol_mapping(), main(), _rollback_destination(), _is_sha256(), ProtocolMappingRegistry, candidate_payload(), consensus_payload() (+4 more)

### Community 100 - "Community 100"
Cohesion: 0.06
Nodes (7): ApplicationRuntimeCharacterizationTests, factory(), __init__(), _NavigationPage, _NavigationShell, _NavigationTabBar, _NavigationTabs

### Community 101 - "Community 101"
Cohesion: 0.13
Nodes (29): format_route_step(), RouteStep, acquisition_options(), apply_dungeon_bundle_holds(), apply_universal_class_gate_bridges(), branch_condition_is_common(), conditional_branch_cards(), dungeon_manual_context() (+21 more)

### Community 102 - "Community 102"
Cohesion: 0.09
Nodes (14): _array(), _coord_from_text(), GuideUltimeRouteAdapter, _safe_coord(), _safe_int(), _safe_map_id(), GuideIntegrityEntrypointsTests, GuideToolCanonicalEntrypointTests (+6 more)

### Community 103 - "Community 103"
Cohesion: 0.08
Nodes (3): GuideCatalogView, GuideCardDelegate, GuideListModel

### Community 104 - "Community 104"
Cohesion: 0.09
Nodes (7): ElevatedHelperProcess, ElevatedWindowsProtocolSource, launch_elevated_capture_helper(), NetworkCaptureStartError, _ShellExecuteInfoW, WindowsElevatedHelperProcess, NetworkCaptureDirectionTests

### Community 105 - "Community 105"
Cohesion: 0.12
Nodes (25): _blocking_function_names(), _call_name(), _collect_imports(), _contains_blocking_call(), _controlled_exec_call_ids(), _direct_blocking_call(), _dynamic_import_targets(), _expression_key() (+17 more)

### Community 106 - "Community 106"
Cohesion: 0.11
Nodes (23): CanonicalToolSpecTests, ToolCatalogTests, _capabilities(), catalog(), _cost_hint(), _derived_side_effects(), _invocation(), _json_cli_flag() (+15 more)

### Community 107 - "Community 107"
Cohesion: 0.11
Nodes (12): DoctorGraphAuditTests, fixture(), fixture(), RuntimeFileFocusTests, audit_current_graph(), _confirm_import(), _domain(), inspect_graph() (+4 more)

### Community 108 - "Community 108"
Cohesion: 0.08
Nodes (3): CharacterSlotsPanel, OrganizerUiMixin, OrganizerLayoutTests

### Community 109 - "Community 109"
Cohesion: 0.09
Nodes (4): ProfileSettingsService, CriticalJsonSchemaTests, ProfileSettingsServiceTests, ProfileStorageBridgeTests

### Community 110 - "Community 110"
Cohesion: 0.08
Nodes (3): AgentVerificationTests, failure(), mutation()

### Community 112 - "Community 112"
Cohesion: 0.15
Nodes (25): AtlasDoctorRuntimeBenchmarkTests, aggregate_samples(), attach_baseline_comparison(), _baseline_medians(), compare_to_baseline(), _current_encyclopedia_page(), current_rss_mb(), _first_achievement_detail() (+17 more)

### Community 113 - "Community 113"
Cohesion: 0.15
Nodes (7): GuideActivity, GuideChapter, GuideObjective, GuidePart, GuideRequiredItem, GuideSeries, _series_heading()

### Community 114 - "Community 114"
Cohesion: 0.07
Nodes (8): _CompactAchievementSources, _local_item_image_index(), build_image_index(), QuestSources, read_selected_json_object_values(), SelectedJsonValueMapping, SelectedJsonValueTests, QuestSourceBoundaryTests

### Community 115 - "Community 115"
Cohesion: 0.13
Nodes (13): _certificate_error(), _character_id_from_key(), install_calibrated_current_profile(), _is_known_legacy_lqn_mapping(), _is_known_legacy_snapshot(), _is_sha256(), _positive_int(), _rollback() (+5 more)

### Community 116 - "Community 116"
Cohesion: 0.12
Nodes (23): achievement_context_section(), achievement_reward_label(), clean_requirement_line(), clear_layout(), _display_item(), format_number(), guides_section(), is_alteration_objective() (+15 more)

### Community 117 - "Community 117"
Cohesion: 0.09
Nodes (12): current_native_thread_id(), stop_message_hook(), _configure_hook_api(), HotkeyRegistry, HotkeySpec, KBDLLHOOKSTRUCT, parse_hotkey(), _tokenize_hotkey() (+4 more)

### Community 118 - "Community 118"
Cohesion: 0.10
Nodes (5): GuideUltimeCardState, GuideUltimeRuntimeService, GuideUltimeStableProgressKeyTests, _ProgressKeyService, GuideUltimeV5RuntimeTests

### Community 119 - "Community 119"
Cohesion: 0.17
Nodes (29): active_manifest_path(), append_journal(), apply_validation(), build_parser(), checkpoint(), ensure_backup(), extracted_block_json(), fetch_quest_pages() (+21 more)

### Community 120 - "Community 120"
Cohesion: 0.10
Nodes (17): GeneratedFileGuardrailsTests, GeneratedFilesGuardTests, RepositoryGitHooksTests, find_forbidden(), find_sensitive_content(), forbidden_reason(), git_paths(), _looks_like_placeholder() (+9 more)

### Community 121 - "Community 121"
Cohesion: 0.15
Nodes (16): AtlasJsonBenchmarkTests, AtlasJsonShardTests, benchmark(), main(), _activate_pointer(), activate_version(), build(), current_directory() (+8 more)

### Community 122 - "Community 122"
Cohesion: 0.08
Nodes (15): _await_startup_cache_warmup(), build_craft_preload(), build_guide_progress_preload(), build_preload_payload(), build_quest_preload(), build_quest_related_preload(), guide_progress_state(), _load_quest_characters() (+7 more)

### Community 123 - "Community 123"
Cohesion: 0.15
Nodes (24): build_row(), build_row_from_values(), candidate_score(), clean_export_dir(), export_image(), export_rank(), export_selected_images(), image_dimensions() (+16 more)

### Community 124 - "Community 124"
Cohesion: 0.11
Nodes (13): apply_bundle(), main(), run_import(), _upsert_cell(), _upsert_class_spell(), _upsert_condition(), _upsert_item_effect(), _upsert_monster_spell() (+5 more)

### Community 125 - "Community 125"
Cohesion: 0.11
Nodes (10): ChangeIntelligenceTests, SourceImpactTests, build_change_plan(), _git(), _imports_deleted_module(), removed_python_modules(), stale_removed_imports(), _safe_relative() (+2 more)

### Community 126 - "Community 126"
Cohesion: 0.16
Nodes (16): DeobfuscationEvidenceValidation, DiscoveryEvidenceCandidate, ProtocolDiscoveryConsensus, MappingEvidenceValidation, validate_mapping_against_consensus(), ProtocolMappingManifest, audit_payload(), audit_protocol_mapping_readiness() (+8 more)

### Community 127 - "Community 127"
Cohesion: 0.07
Nodes (5): worker(), _resolve_craft_page(), _resolve_quest_provider(), ShellReliabilityTests, priority()

### Community 128 - "Community 128"
Cohesion: 0.14
Nodes (20): DoctorIntegrityTimeoutTests, milliseconds(), _decode_lines(), _read_gate_progress(), run_integrity_gate(), _actionable_diagnostics(), baseline_key(), _check_duration_ms() (+12 more)

### Community 129 - "Community 129"
Cohesion: 0.15
Nodes (10): AchievementProgressService, achievement_category_name(), achievement_id(), achievement_objectives(), compare(), objective_done(), objective_parts(), ref_group_done() (+2 more)

### Community 130 - "Community 130"
Cohesion: 0.10
Nodes (3): _resolve_progressive_quests_page_type(), LazyQuestsPage, test_same_quest_detail_signature_skips_full_rerender()

### Community 131 - "Community 131"
Cohesion: 0.10
Nodes (6): D2DataImporter, D2OImporter, JsonImporter, D2DataImporterTests, D2OImporterTests, JsonImporterTests

### Community 132 - "Community 132"
Cohesion: 0.16
Nodes (5): AtlasDoctorTests, tracking_walk(), _git(), _ast_cache_identity(), run_audit()

### Community 133 - "Community 133"
Cohesion: 0.11
Nodes (12): LiveGraphTests, provider(), change_snapshot(), changed_imports(), _direct_imports(), _git(), handler_factory(), do_GET() (+4 more)

### Community 135 - "Community 135"
Cohesion: 0.17
Nodes (10): full(), plan(), ShadowValidationTests, _actual_required_groups(), aggregate_shadows(), evaluate_shadow(), load_full_report(), campaign() (+2 more)

### Community 136 - "Community 136"
Cohesion: 0.10
Nodes (10): GuideActionCanonicalTargetTests, GuideActionDropTests, GuideActionFightTests, GuideActionInteractTests, GuideActionModelTests, GuideActionPreparationContractTests, GuideActionQuestLinksTests, GuideActionUseItemTests (+2 more)

### Community 137 - "Community 137"
Cohesion: 0.08
Nodes (10): ActivityBadge, ActivitySummary, CollapsedColumnRail, CompactScroll, EmptyState, EncyclopediaPanel, HideCompletedButton, RequiredItemRow (+2 more)

### Community 138 - "Community 138"
Cohesion: 0.16
Nodes (16): _active_build_sha256(), build_parser(), create_deobfuscation_evidence_bundle(), DeobfuscationEvidenceBundle, DeobfuscationEvidenceBundleError, DeobfuscationReportDigest, _is_sha256(), load_deobfuscation_evidence_bundle() (+8 more)

### Community 139 - "Community 139"
Cohesion: 0.09
Nodes (4): _FakeManualUiService, _FakeQuestProgress, _FakeQuestProvider, GuideUltimeManualUiNavigationTests

### Community 140 - "Community 140"
Cohesion: 0.14
Nodes (23): _command_tool_paths(), _expression_name(), _git_tracked_paths(), _has_sys_path_mutation(), _is_executable(), _is_wrapper(), _literal_command_tokens(), main() (+15 more)

### Community 141 - "Community 141"
Cohesion: 0.10
Nodes (9): DofusItem, _build_guide_items_index(), _compact_item_payload(), ensure_guide_items_index(), _ensure_guide_items_index_cli(), _guide_item_source_signature(), _iter_doduda_refs(), _read_guide_items_index() (+1 more)

### Community 142 - "Community 142"
Cohesion: 0.08
Nodes (6): LinkService, _AsyncImageDelivery, _decode_guide_image(), _decode_qimage(), _ensure_async_image_delivery(), GuideCollapsedStepsRail

### Community 143 - "Community 143"
Cohesion: 0.14
Nodes (8): QuestCompletionInfoDecoder, QuestCompletionInfoRule, _completion_payload(), _Delegate, _field_bytes(), _field_varint(), QuestCompletionInfoDecoderTests, _varint()

### Community 144 - "Community 144"
Cohesion: 0.22
Nodes (11): TransportSessionClosed, _b(), _idr(), _idz(), _kva(), _kvi(), ProtocolCalibrationTests, _Resolver (+3 more)

### Community 145 - "Community 145"
Cohesion: 0.08
Nodes (6): _FirstIncompleteProbe, GuideUltimeRuntimeProgressCacheTests, _ManualRouteProbe, _RevisionAchievements, _RevisionProgress, _RouteProgressProbe

### Community 146 - "Community 146"
Cohesion: 0.17
Nodes (26): atomic_write_json(), build_craft_list(), cache_api(), _compatibility_adapter(), ensure_dirs(), fetch_recipe_index(), get_cached_image_path(), get_item() (+18 more)

### Community 147 - "Community 147"
Cohesion: 0.09
Nodes (4): GuideSection, GuideStep, GuideSectionWidget, GuideStepWidget

### Community 148 - "Community 148"
Cohesion: 0.16
Nodes (18): achievement_provider_object_counts(), current_encyclopedia_page(), current_rss_mb(), first_achievement_detail(), first_guide_detail(), git_head(), main(), measure() (+10 more)

### Community 149 - "Community 149"
Cohesion: 0.14
Nodes (6): GraphifyDoctorTests, generate(), architecture(), graph_status(), _signature(), summarize_graph()

### Community 150 - "Community 150"
Cohesion: 0.19
Nodes (18): AtlasDoctorPonytailTests, _git(), run_git(), severity_counts(), tracked_files(), _baseline_text(), _broad_diff_findings(), _classes() (+10 more)

### Community 151 - "Community 151"
Cohesion: 0.21
Nodes (5): DofusGuideCandidate, GuideCatalogBuilder, _quest_chain_steps(), _quest_step(), main()

### Community 152 - "Community 152"
Cohesion: 0.09
Nodes (4): canonical_manifest_rows(), _FakeAchievementProgress, _FakeQuestProgress, GuideUltimeManualPreviewTests

### Community 153 - "Community 153"
Cohesion: 0.12
Nodes (6): DecodedNetworkEventSource, FakeDecoder, FakeSource, NetworkTransportTests, decode(), decode()

### Community 155 - "Community 155"
Cohesion: 0.11
Nodes (5): CharacterOrderService, remove(), save(), CharacterOrderServiceTests, Row

### Community 156 - "Community 156"
Cohesion: 0.13
Nodes (15): client_size(), describe_window_row(), _ensure_windows_api(), enumerate_windows(), callback(), hwnd_value(), process_image_path(), scan_unity_sessions() (+7 more)

### Community 157 - "Community 157"
Cohesion: 0.13
Nodes (13): _add(), install(), _json_load(), _json_loads(), main(), _norm(), _read_text(), restore() (+5 more)

### Community 159 - "Community 159"
Cohesion: 0.16
Nodes (11): _b(), CalibrationRuntimeTests, _idz(), _journal(), _kva(), _kvi(), _LateItemSource, _Resolver (+3 more)

### Community 161 - "Community 161"
Cohesion: 0.12
Nodes (5): InterProcessResourceLock, ProgressFileCoordinator, ProgressLockTimeoutError, _hold_resource_lock(), ProgressInterprocessLockingTests

### Community 162 - "Community 162"
Cohesion: 0.15
Nodes (7): _positive_int(), ProtocolFieldCandidate, ProtocolTargetDiscoveryCollector, bytes_field(), encode_varint(), NetworkDiscoveryTests, varint_field()

### Community 163 - "Community 163"
Cohesion: 0.13
Nodes (8): IntegratedDoctorInvestigationTests, TestCostEvidenceTests, _git_head(), _graph_file_evidence(), investigate_files(), _read_trace(), suggest_targeted_test_order(), test_cost_report()

### Community 164 - "Community 164"
Cohesion: 0.15
Nodes (8): DoctorScenarioTrendTests, HistoricalTraceComparisonTests, observed_entered_symbols(), load_scenario_trend(), summarize_scenario_trend(), compare_scenario_traces(), _entered_symbol_names(), _observed_edges()

### Community 165 - "Community 165"
Cohesion: 0.12
Nodes (10): LastClientPoint, _RuntimeCallbackBridge, ControlledHook, _runtime(), _settings(), test_runtime_callback_bridge_discards_stale_worker_active_state(), test_runtime_partial_hook_failure_tears_down_both_hooks(), test_runtime_second_start_during_hook_start_reloads_latest_settings() (+2 more)

### Community 166 - "Community 166"
Cohesion: 0.19
Nodes (14): DirectionMacro, clipboard_text(), _configure_keyboard_api(), key_down(), key_up(), press_hotkey(), press_key(), release_common_inputs() (+6 more)

### Community 167 - "Community 167"
Cohesion: 0.17
Nodes (13): full_calibration_capabilities_ready(), missing_full_calibration_capabilities(), missing_runtime_capabilities(), _normalized_events(), runtime_capabilities_ready(), build_parser(), _configured_handles(), inspect_local_protocol_status() (+5 more)

### Community 168 - "Community 168"
Cohesion: 0.10
Nodes (9): GuideActionAcquisitionTests, GuideActionBuyTests, GuideActionMonsterQuantityTests, GuideActionPositionTests, GuideActionQuantityTests, GuideActionTalkTests, GuideActionTurnInTests, GuideActionTypesCompleteTests (+1 more)

### Community 169 - "Community 169"
Cohesion: 0.17
Nodes (5): LegacyGuideToolConsumerTests, ToolAuditTests, audit(), _reference_paths(), _tool_paths()

### Community 170 - "Community 170"
Cohesion: 0.19
Nodes (9): AdapterWarning, AdventureRouteAdapter, AdventureRouteAdapterResult, _array(), _doduda_rows(), _norm(), _safe_int(), RouteCondition (+1 more)

### Community 172 - "Community 172"
Cohesion: 0.11
Nodes (4): CollapsibleInfoSection, GuideSeriesSummaryRow, QuestLine, GuidesLot5Tests

### Community 174 - "Community 174"
Cohesion: 0.14
Nodes (3): AdaptiveCertificationTests, source(), destroyed()

### Community 175 - "Community 175"
Cohesion: 0.12
Nodes (5): atlas_application_icon(), AtlasDialog, AtlasDialogHeader, CloseActionDialog, UiFoundationTests

### Community 176 - "Community 176"
Cohesion: 0.14
Nodes (9): changed_paths(), _git(), main(), plan(), run_parallel_safe(), run_targeted(), SelectionError, TimedResult (+1 more)

### Community 177 - "Community 177"
Cohesion: 0.12
Nodes (4): _cycle_components(), visit(), QuestGraphService, key()

### Community 178 - "Community 178"
Cohesion: 0.14
Nodes (9): category_sort_key(), display_category(), QuestCategoryGroup, QuestHierarchy, QuestHierarchyPath, QuestHierarchyService, QuestSeries, LazyEncyclopediaServicesPackageTests (+1 more)

### Community 179 - "Community 179"
Cohesion: 0.19
Nodes (20): _artifact_stamp(), _cached_domain_result(), _expanded_source_files(), _last_json_line(), _load_manifest(), main(), _parse_args(), _path_label() (+12 more)

### Community 180 - "Community 180"
Cohesion: 0.18
Nodes (4): RefactorSimulationTests, _path_uses_symlink(), _runtime_consumer_evidence(), simulate_refactor()

### Community 183 - "Community 183"
Cohesion: 0.24
Nodes (10): bytes_field(), CorrelatedCharacterIdentityDecoderTests, encode_varint(), _NullDecoder, roster_entry(), roster_payload(), selected_payload(), selected_payload_with_name() (+2 more)

### Community 186 - "Community 186"
Cohesion: 0.09
Nodes (6): MacroLease, MacroLock, CharacterHotkeyMappingTests, __init__(), __init__(), __init__()

### Community 188 - "Community 188"
Cohesion: 0.21
Nodes (6): FinishedQuestsSnapshotRule, _Delegate, _field_bytes(), _field_varint(), FinishedQuestsSnapshotDecoderTests, _varint()

### Community 190 - "Community 190"
Cohesion: 0.23
Nodes (9): AgentPlannerTests, build_plan(), choose_work_depth(), _execution_tests(), minimum_integrity_mode(), _preferred_validation_tools(), required_groups(), _test_command() (+1 more)

### Community 191 - "Community 191"
Cohesion: 0.20
Nodes (19): test_build_report_ignores_stale_runtime_ready_from_previous_launch(), test_build_report_merges_launcher_pyside_runtime_and_profile(), test_build_report_tolerates_missing_and_corrupt_files(), test_elapsed_ms_handles_midnight_rollover(), _write(), build_report(), _elapsed_ms(), _format_ms() (+11 more)

### Community 192 - "Community 192"
Cohesion: 0.17
Nodes (10): AtlasJsonInventoryTests, audit(), audit_local_json(), _contracts(), _decision(), _family(), main(), _referencers() (+2 more)

### Community 193 - "Community 193"
Cohesion: 0.13
Nodes (8): FunctionalPreloadV2Tests, build_spec(), main(), _parser(), _render(), _scope_seed_paths(), _unique(), WorkSpecError

### Community 194 - "Community 194"
Cohesion: 0.16
Nodes (7): GuideActionNormalizerTests, GuideIntegrityContractsTests, GuideIntegrityStructuredTests, normalize_action(), _actions(), validate_runtime_lines(), validate_structured_actions()

### Community 195 - "Community 195"
Cohesion: 0.31
Nodes (21): build_index(), _changed_paths(), check_index(), classify_path(), _committed_changed_paths(), committed_tree_sha(), drift_report(), _git() (+13 more)

### Community 196 - "Community 196"
Cohesion: 0.16
Nodes (7): _collect_text(), load_ocre_capture_registry(), ocre_bosses_for_stage(), ocre_capture_lines(), ocre_unlock_policy_lines(), _stage_evidence(), GuideUltimeOcreRegistryRuntimeTests

### Community 198 - "Community 198"
Cohesion: 0.23
Nodes (5): _card_coords(), GuideUltimeWalkthroughCard, _safe_coord(), _strip_sentinel_position(), _valid_position_text()

### Community 199 - "Community 199"
Cohesion: 0.12
Nodes (7): established_tcp_flows_for_pids(), _ipv4_from_dword(), _MibTcpRowOwnerPid, _port_from_dword(), _RecordingDecoder, _RecordingReassembler, NetworkWindowsTcpTests

### Community 200 - "Community 200"
Cohesion: 0.22
Nodes (17): _add_candidate(), _binding_path(), cached_class_icon_path_for_window_name(), cached_dofus_class_key_for_character_name(), clear_organizer_icon_cache(), _client_index_path(), _collect_binding_candidates(), _collect_client_candidates() (+9 more)

### Community 202 - "Community 202"
Cohesion: 0.14
Nodes (6): _check_generated_javascript(), _domain(), export_interactive_graph(), load_snapshot_comparison(), merge_runtime_traces(), save_graph_snapshot()

### Community 204 - "Community 204"
Cohesion: 0.12
Nodes (5): _achievement(), _FakeProgressService, _FakeProvider, _LightAchievementsView, OptimizedAchievementsBatchingTests

### Community 205 - "Community 205"
Cohesion: 0.22
Nodes (5): _called_attributes(), _function_node(), _method_node(), PerformanceGuardrailTests, _source()

### Community 206 - "Community 206"
Cohesion: 0.10
Nodes (6): EncyclopediaService, explicit_provider_callable(), worker(), _GuideStagePayload, _NullAchievementProvider, test_encyclopedia_uses_indexed_guide_provider_by_default()

### Community 208 - "Community 208"
Cohesion: 0.13
Nodes (5): _category_order(), GuideBuildResult, _write_json(), QuestClosure, GuidesV4PrerequisitesTests

### Community 210 - "Community 210"
Cohesion: 0.17
Nodes (9): EventPump, _merge_payload(), PreloadReport, PreloadTask, StartupPreloader, worker(), _Pump, _slow_payload() (+1 more)

### Community 211 - "Community 211"
Cohesion: 0.11
Nodes (5): _MutexBackend, SingleInstanceGuard, _WindowsMutexBackend, _FakeMutexBackend, SingleInstanceTests

### Community 212 - "Community 212"
Cohesion: 0.19
Nodes (10): _find_test_method(), _has_verification(), inspect_critical_test(), _is_constant_assertion(), _literal_expression(), _optional_step_issue(), _qualified_name(), _skip_markers() (+2 more)

### Community 214 - "Community 214"
Cohesion: 0.16
Nodes (7): AlphaTests, BetaTests, RandomOrderRunnerTests, flatten(), load_tests(), main(), reproducible_suite()

### Community 215 - "Community 215"
Cohesion: 0.20
Nodes (6): GuideActionContractTests, GuideActionDropContractTests, GuideActionNpcGroupingTests, group_consecutive_talks(), GuideActionViolation, validate_actions()

### Community 216 - "Community 216"
Cohesion: 0.16
Nodes (10): background_io_priority(), _configure_kernel32(), _current_preload_task(), install_preload_priority_bridge(), PreloadUserTaskSet, promote_background_thread(), _register_current_preload_worker(), release_preload_user_priority() (+2 more)

### Community 217 - "Community 217"
Cohesion: 0.15
Nodes (12): _build_manual_runtime_compact_cache_in_worker(), achievement_name_index(), main(), warm_achievement_source_indexes(), write_achievement_name_index(), _guide_domain(), main(), _parse_args() (+4 more)

### Community 218 - "Community 218"
Cohesion: 0.13
Nodes (5): AchievementProgressService, _CompactAchievementProvider, _GuideProvider, MemoryBoundAchievementProgressTests, _QuestProgress

### Community 220 - "Community 220"
Cohesion: 0.14
Nodes (3): EquipmentPage, qwebengine_view_class(), EquipmentDeferredStartTests

### Community 221 - "Community 221"
Cohesion: 0.18
Nodes (6): DevelopmentPreflightTests, DevelopmentPreflightContracts, development_preflight(), _review_python_sources(), _run_focused_tests(), _select_modules()

### Community 222 - "Community 222"
Cohesion: 0.23
Nodes (4): CumulativeCertificationTests, git(), assess_cumulative(), _git()

### Community 223 - "Community 223"
Cohesion: 0.21
Nodes (7): details(), GitHubProvenanceTests, zip_passport(), _api(), check_online(), main(), verify_archive_origin()

### Community 224 - "Community 224"
Cohesion: 0.18
Nodes (7): GuidePlayerContractTests, audit(), _issue(), line_contract_issues(), main(), stage_contract_issues(), _talk_target()

### Community 225 - "Community 225"
Cohesion: 0.23
Nodes (8): _AchievementProvider, _b(), _kva(), _kvi(), OfflineQuestReconciliationTests, _snapshot(), _v(), _varint()

### Community 226 - "Community 226"
Cohesion: 0.20
Nodes (13): _aggregate_global_rewards(), add(), _dedupe_rewards(), display_reward_from_quest(), display_reward_from_source_text(), display_rewards_from_achievement(), DisplayReward, guide_achievements() (+5 more)

### Community 228 - "Community 228"
Cohesion: 0.13
Nodes (4): image_src_from_attrs(), MetaParser, MiniHTMLParser, TokenParser

### Community 229 - "Community 229"
Cohesion: 0.15
Nodes (3): display_saved_character(), load_quest_characters(), CharacterSlotResolverTests

### Community 231 - "Community 231"
Cohesion: 0.20
Nodes (7): audit_mapping_evidence(), audit_payload(), build_parser(), main(), consensus(), mapping_payload(), NetworkMappingAuditTests

### Community 232 - "Community 232"
Cohesion: 0.16
Nodes (3): CraftResourceDialog, quantity_spinbox(), IconCache

### Community 233 - "Community 233"
Cohesion: 0.22
Nodes (10): _clean(), discover_guides(), _fetch_text(), import_guides(), _job_from_title(), main(), parse_guide(), _parse_name_quantity() (+2 more)

### Community 234 - "Community 234"
Cohesion: 0.23
Nodes (8): AgentTaskProfileTests, infer_task_type(), load_config(), main(), _quality_rank(), route_for_task(), select_work_card(), TaskProfileError

### Community 235 - "Community 235"
Cohesion: 0.19
Nodes (9): GuideIntegrityTests, GuideTransversalCanonicalEntrypointTests, _check(), checks_for_mode(), GuideCheck, main(), _render_summary(), run() (+1 more)

### Community 236 - "Community 236"
Cohesion: 0.19
Nodes (6): GuideUltimeActionQualityAuditTests, audit(), _contains_token(), _issue(), _line_issues(), main()

### Community 237 - "Community 237"
Cohesion: 0.23
Nodes (9): PhaseAdaptiveGateTests, plan(), choose_route(), critical_changed(), _git(), _load(), main(), _save() (+1 more)

### Community 238 - "Community 238"
Cohesion: 0.14
Nodes (4): ProgressState, AchievementSummaryWidget, AchievementListModel, ResultList

### Community 241 - "Community 241"
Cohesion: 0.18
Nodes (5): AiContextTests, _commit_all(), _context_map_lists(), _git(), _git_path_exists()

### Community 242 - "Community 242"
Cohesion: 0.16
Nodes (4): DoctorConsumerSiteTests, _candidate_files(), inspect_consumer_sites(), _literal_string()

### Community 243 - "Community 243"
Cohesion: 0.17
Nodes (3): IsolateTriageTests, _trace_observations(), triage_isolates()

### Community 245 - "Community 245"
Cohesion: 0.25
Nodes (4): AtlasMetaIntegrityTests, check_ci_contracts(), check_full_discovery_source(), validate_inventory()

### Community 247 - "Community 247"
Cohesion: 0.16
Nodes (9): _cached_criterion_references(), _criterion_branches(), parse(), CriterionBranch, CriterionReferences, _deduplicate_branches(), _intersection(), _split_top() (+1 more)

### Community 249 - "Community 249"
Cohesion: 0.15
Nodes (3): EncyclopediaThreePanelDashboard, FixedColumnSplitter, FixedColumnSplitterHandle

### Community 250 - "Community 250"
Cohesion: 0.19
Nodes (5): DevEventTests, dev_event(), _git(), _name_status_z(), _normalized()

### Community 252 - "Community 252"
Cohesion: 0.14
Nodes (3): EncyclopediaDemandLoadingTests, _PageProbe, _Tabs

### Community 254 - "Community 254"
Cohesion: 0.14
Nodes (4): _AchievementProgress, _AchievementProvider, GuideUltimeSuccessLinkTests, _Service

### Community 255 - "Community 255"
Cohesion: 0.33
Nodes (7): _active(), _b(), _finished(), QuestSnapshotDiscoveryTests, _snapshot(), _v(), _varint()

### Community 256 - "Community 256"
Cohesion: 0.15
Nodes (5): _bare_runtime(), test_emergency_stop_does_not_materialize_unused_macros(), test_emergency_stop_resets_only_materialized_macros(), test_first_property_access_builds_macro_once_and_reuses_it(), test_macro_property_setter_preserves_test_and_runtime_injection()

### Community 257 - "Community 257"
Cohesion: 0.17
Nodes (10): changed_paths(), classify_diff(), main(), _path_has_direct_test_coverage(), _run_scoped_modules(), ScopeError, contract_plan(), execute_scenarios() (+2 more)

### Community 258 - "Community 258"
Cohesion: 0.17
Nodes (3): _guide_id_from_title(), GuideManualProgressBar, SharedGuideManualView

### Community 259 - "Community 259"
Cohesion: 0.14
Nodes (4): _apply_saved_progress(), _manual_route_stage_total(), _persisted_manual_summary(), _resolve_quest_provider()

### Community 261 - "Community 261"
Cohesion: 0.24
Nodes (4): _clear_connected_background_qrgb(), clear_connected_dark_background(), _is_background_rgb(), SplashImageTests

### Community 264 - "Community 264"
Cohesion: 0.15
Nodes (3): _FakeGuideProvider, _FakeManualService, HomeGuideUltimeSourceTests

### Community 267 - "Community 267"
Cohesion: 0.15
Nodes (6): __getattr__(), __getattr__(), _LazyQuestGraphServiceMeta, _load_quest_graph_service_class(), __getattr__(), __getattr__()

### Community 268 - "Community 268"
Cohesion: 0.26
Nodes (12): audit_from_local_guide(), duffus_url_for_guide(), extract_page_title(), fetch_text(), guide_id_from_url(), main(), route_sort_key(), sitemap_guide_urls() (+4 more)

### Community 270 - "Community 270"
Cohesion: 0.24
Nodes (8): _output_from_environment(), StartupTimeline, _clock(), test_disabled_startup_timeline_has_no_disk_side_effect(), test_future_interpreter_baseline_falls_back_to_current_clock(), test_startup_timeline_flushes_one_json_line(), test_startup_timeline_records_first_occurrence_and_deltas(), test_startup_timeline_uses_interpreter_baseline()

### Community 271 - "Community 271"
Cohesion: 0.29
Nodes (10): _changed_paths(), _digest(), evaluate_phase(), _guide_certification_errors(), _guide_evidence_completeness_errors(), _is_ancestor(), _load_json(), main() (+2 more)

### Community 273 - "Community 273"
Cohesion: 0.27
Nodes (4): DeepFirstUseTimingTests, sample(), compare_deep_first_use(), _milliseconds()

### Community 274 - "Community 274"
Cohesion: 0.34
Nodes (14): Ensure-Pip(), Ensure-Python(), Ensure-PythonModules(), Install-PythonFallback(), Install-WingetPackage(), Invoke-HiddenProcess(), Refresh-ProcessPath(), Resolve-Python313() (+6 more)

### Community 275 - "Community 275"
Cohesion: 0.30
Nodes (3): ScenarioCoverageTests, observed_executing_python_files(), summarize_scenarios()

### Community 277 - "Community 277"
Cohesion: 0.16
Nodes (4): _DummyGuidesView, GuidesHiddenHomeRefreshTests, _GuideUltimeView, _QuestProgress

### Community 279 - "Community 279"
Cohesion: 0.22
Nodes (5): catalog_route_map_count_hint(), catalog_route_map_count(), _position_key(), first_position_from_quest(), LanyelHomeRouteMapCountTests

### Community 280 - "Community 280"
Cohesion: 0.24
Nodes (8): build_related_encyclopedia_data(), RelatedEncyclopediaData, _run_compact_preload_worker(), _warm_achievement_catalogue(), _warm_achievement_source_indexes(), _warm_guide_catalogue(), _warm_guide_files(), _warm_guide_items_index()

### Community 281 - "Community 281"
Cohesion: 0.21
Nodes (6): cached_scaled_pixmap(), clear_guide_home_image_cache(), get_cached_scaled_pixmap(), store_scaled_pixmap(), test_different_requested_size_uses_distinct_scaled_cache_entry(), test_scaled_guide_pixmap_is_reused_without_second_decode()

### Community 286 - "Community 286"
Cohesion: 0.31
Nodes (4): Phase8BudgetEvidenceTests, sample(), assess_memory_benchmark(), _nonnegative()

### Community 287 - "Community 287"
Cohesion: 0.18
Nodes (5): _DummyGuidesView, GuidesBatchProgressTests, _ProgressService, _Scroll, _ScrollBar

### Community 289 - "Community 289"
Cohesion: 0.26
Nodes (10): TargetedMutationTests, execute(), _expect_value_error(), _identity_padding(), _identity_positive(), _identity_prefix(), _json_corruption_backup(), _json_missing_copy() (+2 more)

### Community 290 - "Community 290"
Cohesion: 0.36
Nodes (10): all_named_quests(), build_route(), catalog_unavailable_report(), completed_alternative_satisfied(), _flatten_strings(), load_json(), main(), prerequisite_target() (+2 more)

### Community 294 - "Community 294"
Cohesion: 0.29
Nodes (3): ImageDownloader, main(), ImageDownloaderTests

### Community 295 - "Community 295"
Cohesion: 0.24
Nodes (3): LayerBoundaryTests, _layer(), layer_boundary_review()

### Community 296 - "Community 296"
Cohesion: 0.33
Nodes (3): archived(), plan(), ShadowCampaignTests

### Community 297 - "Community 297"
Cohesion: 0.31
Nodes (4): _connected_source(), ElevatedCaptureControlBufferTests, _FakeConnection, _message()

### Community 299 - "Community 299"
Cohesion: 0.33
Nodes (7): GuideUltimeSupportRoutesAuditTests, audit(), _audit_player_text(), _canonical_temporal_hooks(), _issue(), main(), _quest_name_index()

### Community 300 - "Community 300"
Cohesion: 0.22
Nodes (7): classify_root_of_trust_changes(), detect_sensitive_changes(), _git_paths(), main(), _print_human(), _read_json(), verify_repository()

### Community 302 - "Community 302"
Cohesion: 0.44
Nodes (10): classify(), collect_route_evidence(), _evaluate_contract(), evaluate_success_contracts(), label_is_explicit(), load(), main(), norm() (+2 more)

### Community 303 - "Community 303"
Cohesion: 0.21
Nodes (4): _achievement_name_index(), IndexedGuideProvider, add_achievement(), test_indexed_guide_provider_reuses_hot_achievement_provider()

### Community 304 - "Community 304"
Cohesion: 0.24
Nodes (4): _LazyAchievementProviderMeta, _LazyGuideProviderMeta, _load_achievement_provider_class(), _load_guide_provider_class()

### Community 305 - "Community 305"
Cohesion: 0.18
Nodes (6): format_number(), _apply_item_row_state(), _fallback_item_icon(), item_row(), toggle(), row()

### Community 306 - "Community 306"
Cohesion: 0.24
Nodes (5): lazy_achievement_progress_service(), lazy_guide_progress_service(), LazyProgressService, _load_achievement_progress(), _load_guide_progress()

### Community 307 - "Community 307"
Cohesion: 0.18
Nodes (5): decode_scaled_image(), install_guide_image_runtime_policy(), decode_guide_image(), decode_solution_image(), test_guide_decode_never_keeps_full_source_raster()

### Community 309 - "Community 309"
Cohesion: 0.23
Nodes (6): _fill(), get(), peek(), read_string_span(), read_value_span(), skip_space()

### Community 311 - "Community 311"
Cohesion: 0.32
Nodes (4): DoctorCapabilityContractsTests, _call_names(), capability_inventory(), _test_case_defined()

### Community 312 - "Community 312"
Cohesion: 0.18
Nodes (5): DoctorResourceLifecycleSourceTests, main(), __init__(), inspect_resource_lifecycle(), _name()

### Community 313 - "Community 313"
Cohesion: 0.26
Nodes (4): AtlasLifecycleSoakTests, execute(), _flatten(), main()

### Community 315 - "Community 315"
Cohesion: 0.26
Nodes (4): CriticalCoverageTests, execute(), load_policy(), main()

### Community 318 - "Community 318"
Cohesion: 0.26
Nodes (4): achievement(), FakeAchievementProvider, FakeQuestProvider, quest()

### Community 321 - "Community 321"
Cohesion: 0.17
Nodes (4): ComparablePreloadCacheIsolationTests, DeepAchievementTimingContractTests, DeepQuestTimingContractTests, QuestSourcePhaseProfilingContractTests

### Community 325 - "Community 325"
Cohesion: 0.31
Nodes (4): clear_quest_character_cache(), QuestCharacterCacheTests, fake_loader(), _write()

### Community 334 - "Community 334"
Cohesion: 0.22
Nodes (3): GuideUltimeLightweightAchievementIndexTests, _LoadedProvider, _UnloadedProvider

### Community 338 - "Community 338"
Cohesion: 0.20
Nodes (4): _class_methods(), test_only_shared_guide_classes_own_visual_composition(), test_shared_renderer_is_guide_agnostic(), test_sylvestre_has_no_dedicated_ui_file_or_class()

### Community 340 - "Community 340"
Cohesion: 0.31
Nodes (3): derive_completion_state(), _safe_int(), AchievementProgressLogicTests

### Community 341 - "Community 341"
Cohesion: 0.38
Nodes (4): QuestSourceError, GuideUltimeCatalogFailureTests, load_provider_achievements(), load_provider_quests()

### Community 343 - "Community 343"
Cohesion: 0.40
Nodes (6): build_graph(), commands(), detect(), install_graphify(), main(), _tool_environment()

### Community 346 - "Community 346"
Cohesion: 0.24
Nodes (3): _FailIfCalled, OptimizedAchievementsRefreshTests, _ProgressProbe

### Community 348 - "Community 348"
Cohesion: 0.38
Nodes (4): metric_payload(), Phase8MemoryAdvisoryPolicyTests, run_validation(), validation_code()

### Community 349 - "Community 349"
Cohesion: 0.29
Nodes (3): _FailIfCalled, _ProgressProbe, QuestsExternalProgressRefreshTests

### Community 352 - "Community 352"
Cohesion: 0.36
Nodes (6): achievement_quest_ids(), add_achievement(), add_quest(), add_references(), root_achievement_quest_ids(), safe_int()

### Community 353 - "Community 353"
Cohesion: 0.42
Nodes (6): build_parser(), _character_names_for_slot(), _collector_for_event(), main(), _positive_int(), run_discovery_probe()

### Community 357 - "Community 357"
Cohesion: 0.25
Nodes (4): FocusedFunctionInventoryTests, compare_source_functions(), _functions(), visit()

### Community 360 - "Community 360"
Cohesion: 0.44
Nodes (3): GuideUltimeIvoireExitInteractionsTests, _stage(), _texts()

### Community 362 - "Community 362"
Cohesion: 0.33
Nodes (4): _ReloadProbe, test_changed_guide_ultime_progress_refreshes_once_and_marks_signature(), test_unchanged_guides_external_progress_returns_before_any_work(), _ViewProbe

### Community 365 - "Community 365"
Cohesion: 0.54
Nodes (3): parse_ipv4_tcp_packet(), ipv4_tcp_packet(), NetworkIpv4SafetyTests

### Community 380 - "Community 380"
Cohesion: 0.50
Nodes (5): hotspots_payload(), main(), _print_payload(), _scope_hotspot_detail(), _shared_dependency_consumers()

### Community 384 - "Community 384"
Cohesion: 0.33
Nodes (4): empty_detail_html(), _render_static_theme_template(), render_theme_template(), _render_theme_template()

### Community 389 - "Community 389"
Cohesion: 0.38
Nodes (3): FileCoverageTests, file_coverage(), tracked_python()

### Community 391 - "Community 391"
Cohesion: 0.52
Nodes (3): GuideFullSuiteFixtureBudgetTests, _method_calls(), _slow_method()

### Community 412 - "Community 412"
Cohesion: 0.60
Nodes (5): _source(), test_combat_rows_use_neutral_translucent_shared_style(), test_detached_combat_fallback_is_gone(), test_lanyel_position_deduplication_is_part_of_shared_renderer(), test_progress_strip_is_built_before_scroll_and_bottom_navigation()

### Community 417 - "Community 417"
Cohesion: 0.53
Nodes (3): reverse_impact(), node_path(), _source_path()

### Community 419 - "Community 419"
Cohesion: 0.53
Nodes (3): execute(), load_inventory(), main()

### Community 420 - "Community 420"
Cohesion: 0.60
Nodes (3): ensure_placeholder_asset(), load_map_pixmap(), resolve_asset_path()

### Community 421 - "Community 421"
Cohesion: 0.60
Nodes (3): _audited_count(), main(), _validate_alignment_separation()

### Community 426 - "Community 426"
Cohesion: 0.70
Nodes (4): _fake(), test_changed_character_sources_reload_once_and_publish_signature(), test_empty_character_state_is_reloaded_even_with_same_signature(), test_unchanged_character_sources_skip_legacy_reload()

### Community 436 - "Community 436"
Cohesion: 0.80
Nodes (4): Invoke-GuideTestOrReuse(), Invoke-LoggedNative(), Invoke-PythonCheck(), Write-LogLine()

## Knowledge Gaps
- **13 isolated node(s):** `_HotkeyWindowMixin`, `KBDLLHOOKSTRUCT`, `MSLLHOOKSTRUCT`, `POINT`, `PathProfile` (+8 more)
  These have ≤1 connection - possible missing edges. (Counts symbols only; 2680 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **194 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `GuidesView` connect `Community 19` to `Community 0`, `Community 1`, `Community 142`, `Community 15`, `Community 18`, `Community 147`, `Community 277`, `Community 152`, `Community 282`, `Community 29`, `Community 287`, `Community 171`, `Community 44`, `Community 172`, `Community 317`, `Community 92`, `Community 226`, `Community 103`, `Community 362`, `Community 111`, `Community 113`, `Community 244`, `Community 376`, `Community 249`?**
  _High betweenness centrality (0.040) - this node is a cross-community bridge._
- **Why does `QuestCatalog` connect `Community 10` to `Community 0`, `Community 1`, `Community 2`, `Community 3`, `Community 259`, `Community 6`, `Community 7`, `Community 264`, `Community 9`, `Community 11`, `Community 144`, `Community 20`, `Community 280`, `Community 24`, `Community 413`, `Community 29`, `Community 31`, `Community 32`, `Community 159`, `Community 36`, `Community 37`, `Community 40`, `Community 49`, `Community 178`, `Community 59`, `Community 318`, `Community 66`, `Community 67`, `Community 69`, `Community 201`, `Community 332`, `Community 79`, `Community 92`, `Community 95`, `Community 225`, `Community 240`, `Community 116`, `Community 119`, `Community 381`?**
  _High betweenness centrality (0.036) - this node is a cross-community bridge._
- **Why does `AchievementsView` connect `Community 22` to `Community 1`, `Community 40`, `Community 9`, `Community 204`, `Community 13`, `Community 346`, `Community 249`, `Community 26`, `Community 29`, `Community 57`?**
  _High betweenness centrality (0.036) - this node is a cross-community bridge._
- **What connects `_HotkeyWindowMixin`, `KBDLLHOOKSTRUCT`, `MSLLHOOKSTRUCT` to the rest of the system?**
  _13 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Community 0` be split into smaller, more focused modules?**
  _Cohesion score 0.026205726653212833 - nodes in this community are weakly interconnected._
- **Should `Community 1` be split into smaller, more focused modules?**
  _Cohesion score 0.02981788326615913 - nodes in this community are weakly interconnected._
- **Should `Community 2` be split into smaller, more focused modules?**
  _Cohesion score 0.021219715956558062 - nodes in this community are weakly interconnected._