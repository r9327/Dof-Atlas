# Graph Report - Dof-Atlas  (2026-10-14)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 12637 nodes · 36460 edges · 496 communities (309 shown, 187 thin omitted)
- Extraction: 94% EXTRACTED · 6% INFERRED · 0% AMBIGUOUS · INFERRED: 2100 edges (avg confidence: 0.91)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `ac07be9b`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- Community 0
- Community 1
- Community 2
- Community 3
- Community 4
- Community 5
- Community 6
- Community 7
- Community 8
- Community 9
- Community 10
- Community 11
- Community 12
- Community 13
- Community 14
- Community 15
- Community 16
- Community 17
- Community 18
- Community 19
- Community 20
- Community 21
- Community 22
- Community 23
- Community 24
- Community 25
- Community 26
- Community 27
- Community 28
- Community 29
- Community 30
- Community 31
- Community 32
- Community 33
- Community 34
- Community 35
- Community 36
- Community 37
- Community 38
- Community 39
- Community 40
- Community 41
- Community 42
- Community 43
- Community 44
- Community 45
- Community 46
- Community 47
- Community 48
- Community 49
- Community 50
- Community 51
- Community 52
- Community 53
- Community 54
- Community 55
- Community 56
- Community 57
- Community 58
- Community 59
- Community 60
- Community 61
- Community 62
- Community 63
- Community 64
- Community 65
- Community 66
- Community 67
- Community 68
- Community 69
- Community 70
- Community 71
- Community 72
- Community 73
- Community 74
- Community 75
- Community 76
- Community 77
- Community 78
- Community 79
- Community 80
- Community 81
- Community 82
- Community 83
- Community 84
- Community 85
- Community 86
- Community 87
- Community 88
- Community 89
- Community 90
- Community 91
- Community 92
- Community 93
- Community 94
- Community 95
- Community 96
- Community 97
- Community 98
- Community 99
- Community 100
- Community 101
- Community 102
- Community 103
- Community 104
- Community 105
- Community 106
- Community 107
- Community 108
- Community 109
- Community 110
- Community 111
- Community 112
- Community 113
- Community 114
- Community 115
- Community 116
- Community 117
- Community 118
- Community 119
- Community 120
- Community 121
- Community 122
- Community 123
- Community 124
- Community 125
- Community 126
- Community 127
- Community 128
- Community 129
- Community 130
- Community 131
- Community 132
- Community 133
- Community 134
- Community 135
- Community 136
- Community 137
- Community 138
- Community 139
- Community 140
- Community 141
- Community 142
- Community 143
- Community 144
- Community 145
- Community 146
- Community 147
- Community 148
- Community 149
- Community 150
- Community 151
- Community 152
- Community 153
- Community 154
- Community 155
- Community 156
- Community 157
- Community 158
- Community 159
- Community 160
- Community 161
- Community 162
- Community 163
- Community 164
- Community 165
- Community 166
- Community 167
- Community 168
- Community 169
- Community 170
- Community 171
- Community 172
- Community 173
- Community 174
- Community 175
- Community 176
- Community 177
- Community 178
- Community 179
- Community 180
- Community 181
- Community 182
- Community 183
- Community 184
- Community 185
- Community 186
- Community 187
- Community 188
- Community 189
- Community 190
- Community 191
- Community 192
- Community 193
- Community 194
- Community 195
- Community 196
- Community 197
- Community 198
- Community 199
- Community 200
- Community 201
- Community 202
- Community 203
- Community 204
- Community 205
- Community 206
- Community 207
- Community 208
- Community 209
- Community 210
- Community 211
- Community 212
- Community 213
- Community 214
- Community 215
- Community 216
- Community 217
- Community 218
- Community 219
- Community 220
- Community 221
- Community 222
- Community 223
- Community 224
- Community 225
- Community 226
- Community 227
- Community 228
- Community 229
- Community 230
- Community 231
- Community 232
- Community 233
- Community 234
- Community 235
- Community 236
- Community 237
- Community 238
- Community 239
- Community 240
- Community 241
- Community 242
- Community 243
- Community 244
- Community 245
- Community 246
- Community 247
- Community 248
- Community 249
- Community 250
- Community 251
- Community 252
- Community 253
- Community 254
- Community 255
- Community 256
- Community 257
- Community 258
- Community 259
- Community 260
- Community 261
- Community 262
- Community 263
- Community 264
- Community 265
- Community 266
- Community 267
- Community 268
- Community 269
- Community 270
- Community 271
- Community 272
- Community 273
- Community 274
- Community 275
- Community 276
- Community 277
- Community 278
- Community 279
- Community 280
- Community 281
- Community 282
- Community 283
- Community 284
- Community 285
- Community 286
- Community 287
- Community 288
- Community 289
- Community 290
- Community 291
- Community 292
- Community 293
- Community 294
- Community 295
- Community 296
- Community 297
- Community 298
- Community 299
- Community 300
- Community 301
- Community 302
- Community 303
- Community 304
- Community 305
- Community 306
- Community 307
- Community 308
- Community 309
- Community 310
- Community 311
- Community 312
- Community 313
- Community 314
- Community 315
- Community 316
- Community 317
- Community 318
- Community 319
- Community 320
- Community 321
- Community 322
- Community 323
- Community 324
- Community 325
- Community 326
- Community 327
- Community 328
- Community 329
- Community 330
- Community 331
- Community 332
- Community 333
- Community 334
- Community 335
- Community 336
- Community 337
- Community 338
- Community 339
- Community 340
- Community 341
- Community 342
- Community 343
- Community 344
- Community 345
- Community 346
- Community 348
- Community 349
- Community 350
- Community 351
- Community 352
- Community 353
- Community 354
- Community 355
- Community 356
- Community 357
- Community 358
- Community 359
- Community 360
- Community 362
- Community 363
- Community 364
- Community 365
- Community 366
- Community 367
- Community 368
- Community 369
- Community 370
- Community 371
- Community 372
- Community 373
- Community 374
- Community 375
- Community 376
- Community 377
- Community 378
- Community 379
- Community 380
- Community 381
- Community 382
- Community 383
- Community 384
- Community 385
- Community 386
- Community 387
- Community 388
- Community 389
- Community 390
- Community 391
- Community 392
- Community 393
- Community 394
- Community 395
- Community 396
- Community 397
- Community 398
- Community 399
- Community 400
- Community 401
- Community 402
- Community 403
- Community 404
- Community 405
- Community 406
- Community 408
- Community 409
- Community 410
- Community 411
- Community 412
- Community 413
- Community 414
- Community 415
- Community 416
- Community 417
- Community 418
- Community 419
- Community 420
- Community 422
- Community 423
- Community 424
- Community 425
- Community 426
- Community 427
- Community 428
- Community 429
- Community 430
- Community 431
- Community 432
- Community 433
- Community 434
- Community 435
- Community 437
- Community 438
- Community 439
- Community 440
- Community 441
- Community 442
- Community 443
- Community 444
- Community 445
- Community 446
- Community 447
- Community 448
- Community 449
- Community 450
- Community 451
- Community 452
- Community 453
- Community 454
- Community 455
- Community 456
- Community 457
- Community 458
- Community 459
- Community 460
- Community 464
- Community 465
- Community 466
- Community 467
- Community 468
- Community 469
- Community 470
- Community 471
- Community 472
- Community 473
- Community 474
- Community 475
- Community 476
- Community 477
- Community 478
- Community 479
- Community 480
- Community 481
- Community 482
- Community 483

## God Nodes (most connected - your core abstractions)
1. `normalize_text()` - 193 edges
2. `CapturedProtocolMessage` - 192 edges
3. `QuestCatalog` - 184 edges
4. `QuestRecord` - 176 edges
5. `load_manual_chapter()` - 158 edges
6. `QuestProgressService` - 157 edges
7. `GuidesView` - 139 edges
8. `AtlasWindow` - 137 edges
9. `Guide` - 111 edges
10. `QuestProvider` - 100 edges

## Surprising Connections (you probably didn't know these)
- `record()` --indirect_call--> `source()`  [INFERRED]
  tools/atlas_doctor_lib/runtime_observation.py → tests/test_doctor_certification.py
- `observed_slot()` --indirect_call--> `source()`  [INFERRED]
  tools/atlas_doctor_lib/runtime_observation.py → tests/test_doctor_certification.py
- `__init__()` --indirect_call--> `catalog()`  [INFERRED]
  tests/test_startup_resource_contracts.py → tools/tool_catalog.py
- `_quest_name_index()` --uses--> `QuestProvider`  [INFERRED]
  tools/audit_guide_ultime_support_routes.py → app/modules/encyclopedia/providers/quest_provider.py
- `QuestVisualsLot6Tests` --uses--> `QuestViewContext`  [INFERRED]
  tests/test_quest_visuals_lot6.py → app/modules/encyclopedia/widgets/quest_detail_view.py

## Import Cycles
- None detected.

## Communities (496 total, 187 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.02
Nodes (18): CommandEvidenceTests, _PassingProbe, CharacterPySideDiagnosticsTests, ConstantsImportSideEffectsTests, WorkflowContractTests, EncyclopediaCharacterSyncDedupeTests, GuidePlayerContractRunnerTests, GuideStructuredContractDocsTests (+10 more)

### Community 1 - "Community 1"
Cohesion: 0.04
Nodes (29): log_uncaught_exception(), AchievementProvider, __getattr__(), GuideProvider, QuestProvider, quest_start_info(), build_related_encyclopedia_data(), QuestGraphService (+21 more)

### Community 2 - "Community 2"
Cohesion: 0.03
Nodes (51): _is_default_data_dir(), _shared_default_catalog(), quest_level_text(), QuestsPage, _catalog_from_cache_payload(), _catalog_to_cache_payload(), load_lazy_catalog(), display_saved_character() (+43 more)

### Community 3 - "Community 3"
Cohesion: 0.03
Nodes (38): load_manual_chapter(), GuideUltimeAbyssalExitCausalityTests, GuideUltimeAbyssalRerunCausalityTests, GuideUltimeFinalTransversalValidatorTests, GuideUltimeFratrieNecronyxCausalityTests, _stage(), _texts(), GuideUltimeGrolloumCausalityTests (+30 more)

### Community 4 - "Community 4"
Cohesion: 0.05
Nodes (27): AchievementCompletedEvent, AchievementObjectiveCompletedEvent, CharacterIdentifiedEvent, FinishedQuestsSnapshotEvent, NetworkEvent, QuestCompletedEvent, QuestJournalSnapshotEvent, QuestObjectiveCompletedEvent (+19 more)

### Community 5 - "Community 5"
Cohesion: 0.05
Nodes (26): background_io_priority(), _configure_kernel32(), _current_preload_task(), promote_background_thread(), _register_current_preload_worker(), _unregister_preload_worker(), current_native_thread_id(), _configure_hook_api() (+18 more)

### Community 6 - "Community 6"
Cohesion: 0.04
Nodes (35): AdminAudit, audit_client_admin_rights(), current_process_is_admin(), process_id_for_window(), process_is_elevated(), TOKEN_ELEVATION, main(), _preferred_capture_source() (+27 more)

### Community 7 - "Community 7"
Cohesion: 0.04
Nodes (58): item_id(), normalize_key(), parse_unit_ratio(), read_zaap_button_ratios(), zaap_ratios_from_payload(), build_compact_craft_preload(), main(), class_icon_candidates() (+50 more)

### Community 8 - "Community 8"
Cohesion: 0.06
Nodes (44): ensure_dirs(), ensure_directories(), LocalDataConfig, D2DataImporter, D2IImporter, D2OImporter, decode_row(), export_all() (+36 more)

### Community 9 - "Community 9"
Cohesion: 0.06
Nodes (10): clean_auto_group_name(), strip_accents(), CharacterSessionsMixin, session_hwnd(), session_is_detected(), session_is_empty(), session_name(), OrganizerDragDropMixin (+2 more)

### Community 10 - "Community 10"
Cohesion: 0.06
Nodes (31): _candidate_achievement_snapshot(), _candidate_character_stats(), _characteristic_container_value(), _expected_characteristic_container(), _signed_int64(), _singular_signed_scalar(), _MutableTypeDiagnostic, protocol_payload_scalar_samples() (+23 more)

### Community 11 - "Community 11"
Cohesion: 0.04
Nodes (28): __getattr__(), GuideUltimeManualRuntimeService, apply_player_line_policy(), ensure_drop_purchase_alternative(), has_actionable_drop(), _has_player_action(), has_purchase_alternative(), _is_consequence_boundary() (+20 more)

### Community 12 - "Community 12"
Cohesion: 0.07
Nodes (40): empty_summary(), import_map_view_manifest(), load_manifest(), validate_manifest(), get_map_status(), get_status_color(), mark_unverified(), mark_verified() (+32 more)

### Community 13 - "Community 13"
Cohesion: 0.06
Nodes (25): CorrelatedCharacterIdentityDecoder, CorrelatedCharacterIdentityRule, _is_sha256(), ProtocolFieldRule, ProtocolMessageRule, StrictMappedProtocolDecoder, CapturedProtocolMessage, NetworkAuditRegressionTests (+17 more)

### Community 14 - "Community 14"
Cohesion: 0.07
Nodes (5): clear_layout(), GuidesView, restore_side_scrolls(), _single_shot(), test_external_signature_compares_all_progress_sources_and_character()

### Community 15 - "Community 15"
Cohesion: 0.05
Nodes (34): ActiveProtocolBuildFingerprintProvider, _CachedFingerprint, _file_signature(), process_executable_path(), protocol_build_files_for_executable(), protocol_build_sha256(), ProtocolBuildFiles, build_parser() (+26 more)

### Community 16 - "Community 16"
Cohesion: 0.05
Nodes (24): _candidate_level(), CharacterRuntimeProtocolMessageDecoder, CharacterRuntimeStateStore, _achievements_payload(), CharacterRuntimeProtocolMessageDecoderTests, _Delegate, _level_payload(), _message() (+16 more)

### Community 17 - "Community 17"
Cohesion: 0.06
Nodes (5): AtlasPageTitle, AtlasWindow, _resolve_encyclopedia_page(), _resolve_quest_provider(), AtlasWindowRuntimeCleanupTests

### Community 18 - "Community 18"
Cohesion: 0.06
Nodes (18): baseline_keys(), format_unexpected(), legacy_import_violations(), _module_is_legacy(), parse_source(), _qualified_name(), read_source(), _root_name() (+10 more)

### Community 19 - "Community 19"
Cohesion: 0.05
Nodes (8): _achievement_detail_widget_type(), _achievement_entity_row_type(), _AchievementListRef, AchievementsView, _alignment_guide_ids(), _alignment_order_achievement_ranks(), _order_quest_ids(), AchievementLot7AlignmentTests

### Community 20 - "Community 20"
Cohesion: 0.06
Nodes (11): require_character_key(), _empty_progress(), load_quest_progress(), _quest_progress_schema_error(), QuestProgressService, CharacterWriteBoundaryTests, ProgressConcurrentInstanceTests, _mutate_quest() (+3 more)

### Community 21 - "Community 21"
Cohesion: 0.05
Nodes (25): backup_corrupt_json(), InvalidPersistentJsonError, _is_shared_profile_path(), read_json_resilient(), _reject_persistent_json(), _same_path(), write_json_atomic(), _write_json_atomic_unchecked() (+17 more)

### Community 22 - "Community 22"
Cohesion: 0.06
Nodes (55): DisplaySolutionBlock, activity_chip_grid(), activity_icon_key(), activity_labels(), atlas_icon(), _catalog_subtitle(), _category_breadcrumb_label(), clean_requirement_line() (+47 more)

### Community 23 - "Community 23"
Cohesion: 0.07
Nodes (32): fixture(), GraphIntelligenceTests, fixture(), RuntimeFileFocusTests, summarize_graph(), audit_current_graph(), _confirm_import(), _path() (+24 more)

### Community 24 - "Community 24"
Cohesion: 0.07
Nodes (58): activity_labels(), _add_unique_line(), _aggregate_global_rewards(), add(), clean_requirement_line(), _clean_solution_instruction_text(), clean_text(), _count_label() (+50 more)

### Community 25 - "Community 25"
Cohesion: 0.10
Nodes (42): architecture(), _signature(), cache_matches_git(), git_state(), _json_path(), load_json(), milliseconds(), project_root() (+34 more)

### Community 26 - "Community 26"
Cohesion: 0.08
Nodes (16): GuideUltimeManualRuntimeService, fingerprint(), player_line(), player_value(), remember(), _manual_bundle_cache_key(), _manual_bundle_catalog_signature(), _manual_bundle_snapshot() (+8 more)

### Community 27 - "Community 27"
Cohesion: 0.10
Nodes (58): array_from_any(), base_enriched_quest(), block_to_json(), build_mapping(), build_parser(), clean_duffus_step_text(), clean_text(), collect_prerequisite_metadata_line() (+50 more)

### Community 28 - "Community 28"
Cohesion: 0.08
Nodes (8): EncyclopediaPage, worker(), _has_embedded_search(), _is_achievements_view(), _is_guides_view(), _QuestRuntimePayload, _resolve_achievements_view_type(), _resolve_guide_catalog_view_type()

### Community 29 - "Community 29"
Cohesion: 0.06
Nodes (8): Achievement, _achievement_from_dict(), _dump_default_detail(), MemoryBoundAchievementProvider, _progress_objectives_from_rows(), progress_achievement(), AchievementCompactSubprocessTests, AchievementDetailWorkerFastPathTests

### Community 30 - "Community 30"
Cohesion: 0.07
Nodes (27): build_craft_list(), craft_category_for_item(), decorate_craft_items(), get_adapter(), get_cached_image_path(), get_item(), get_item_by_name(), get_item_image() (+19 more)

### Community 31 - "Community 31"
Cohesion: 0.07
Nodes (13): DeepIntelligenceTests, architectural_guardrails(), graph_reachability(), inspect_code(), launcher_entrypoints(), _missing_internal_imports(), _relative(), scan_sources() (+5 more)

### Community 32 - "Community 32"
Cohesion: 0.04
Nodes (12): NetworkEventRuntime, FakeNetworkSource, FailingThread, FakeBridge, FakeSource, LateEventSource, NetworkRuntimeLifecycleTests, ReasonedFailingSource (+4 more)

### Community 33 - "Community 33"
Cohesion: 0.06
Nodes (18): _expected(), _full(), GuideExactFullEvidenceTests, FullSuiteStructuredReuseTests, passing(), GuideCriterionScopeBoundaryTests, canonical(), ids() (+10 more)

### Community 34 - "Community 34"
Cohesion: 0.12
Nodes (47): DoctorUiCaptureContracts, _audit(), build_parser(), command_all(), command_audit(), command_capabilities(), command_capture_ui(), command_certification() (+39 more)

### Community 35 - "Community 35"
Cohesion: 0.08
Nodes (3): DoctorGraphUiTests, compact_graph(), render_html()

### Community 36 - "Community 36"
Cohesion: 0.06
Nodes (46): MemoryPolicyContractUnittest, test_achievement_provider_releases_reconstructible_source_maps(), test_achievement_sync_uses_compact_alignment_guide_ids(), test_atlas_manual_guide_disables_bundle_copy_and_wrapper_duplicate_snapshots(), test_background_related_preload_keeps_runtime_imports_out_of_parent(), test_craft_preload_and_runtime_are_sqlite_bounded(), test_disk_only_preload_does_not_import_home_encyclopedia_runtime(), test_dofus_item_extraction_does_not_parse_monolithic_sources_in_parent() (+38 more)

### Community 38 - "Community 38"
Cohesion: 0.10
Nodes (15): safe_int(), _collect_guide_item_ids(), walk(), _first_int(), GuideProvider, visit(), add_achievement(), matches() (+7 more)

### Community 39 - "Community 39"
Cohesion: 0.07
Nodes (10): _empty_progress(), _guide_progress_schema_error(), GuideProgressService, read_json_resilient(), GuideProgressManualCacheTests, GuideProgressPersistenceTests, CharacterIdProgressStorageTests, _AchievementProvider (+2 more)

### Community 40 - "Community 40"
Cohesion: 0.07
Nodes (15): _copy_identity(), _copy_step_validated(), dofus_361010_candidate_manifest(), dofus_361010_candidate_mapping_payload(), dofus_361010_profile_digest(), _is_current_type_url(), _is_sha256(), ReviewedProtocolProfile (+7 more)

### Community 41 - "Community 41"
Cohesion: 0.11
Nodes (6): GuideUltimeManualConditionsMixin, _manual_card_static_key(), category_sort_key(), display_category(), QuestHierarchyService, normalize_text()

### Community 42 - "Community 42"
Cohesion: 0.06
Nodes (21): __getattr__(), _BpfProgram, _decode_error(), _ipv4_addresses(), ipv4_packet_from_link_frame(), NpcapCaptureError, _NpcapCaptureHandle, _NpcapDevice (+13 more)

### Community 43 - "Community 43"
Cohesion: 0.06
Nodes (11): get_runtime_logger(), build_windows_network_runtime(), _is_sha256(), build_windows_protocol_calibration(), _is_sha256(), DiagnosticProtocolMessageDecoder, DiagnosticProtocolMessageSource, NetworkEventSource (+3 more)

### Community 44 - "Community 44"
Cohesion: 0.05
Nodes (11): HotkeyAction, HotkeyRegistry, HotkeyReport, HotkeySpec, parse_hotkey(), _tokenize_hotkey(), _vk_for_character(), InputState (+3 more)

### Community 45 - "Community 45"
Cohesion: 0.09
Nodes (28): _achievement_index(), _achievement_index_from_loaded_provider(), _achievement_provider_signature(), _aggregate_quantity_targets(), build_card_auto_validation_contract(), build_route_auto_validation_contract(), _build_route_auto_validation_contract_uncached(), _dungeon_name() (+20 more)

### Community 46 - "Community 46"
Cohesion: 0.08
Nodes (10): AchievementProgressService, _achievement_progress_schema_error(), AchievementProgressService, _empty_progress(), read_json_resilient(), AchievementProgressConcurrentInstanceTests, AchievementProgressJsonStoreTests, ProgressMutationIdempotenceTests (+2 more)

### Community 48 - "Community 48"
Cohesion: 0.13
Nodes (44): AgentConfigError, _anchor_specificity(), _declared_ownership_conflicts(), doctor_payload(), _git(), hotspots_payload(), main(), _print_payload() (+36 more)

### Community 49 - "Community 49"
Cohesion: 0.05
Nodes (14): install_preload_priority_bridge(), PreloadUserTaskSet, release_preload_user_priority(), request_preload_user_priority(), PreloadProgressPopup, EncyclopediaOnDemandTests, FunctionalPreloadV2Tests, build_spec() (+6 more)

### Community 50 - "Community 50"
Cohesion: 0.07
Nodes (17): AchievementObjective, EntityRef, GuideObjective, _compact_achievement_dict(), _compact_objective_dict(), _dump_compact_default_catalogue(), _entity_ref_from_dict(), _entity_ref_to_dict() (+9 more)

### Community 51 - "Community 51"
Cohesion: 0.10
Nodes (40): _local_item_image_index(), achievement_quest_series(), achievements_by_quest(), add_unique(), apply_quest_enrichment(), array_value(), criteria_to_lines(), dedupe_rewards() (+32 more)

### Community 52 - "Community 52"
Cohesion: 0.06
Nodes (6): CharacterSlotResolver, CharacterBindingCoordinationTests, CharacterBindingRecoveryTests, CharacterPidOwnershipTests, NetworkCharacterBindingClassMetadataTests, CharacterSlotResolverTests

### Community 53 - "Community 53"
Cohesion: 0.09
Nodes (33): _capture(), _descendant_rows(), main(), measure(), memory_snapshot(), _open_guide_with_probe(), _open_rich_guide_with_probe(), probed_manual_loader() (+25 more)

### Community 54 - "Community 54"
Cohesion: 0.09
Nodes (27): default_profiles(), parse_unit_ratio(), parse_zaap_click_position(), profile_bool(), read_zaap_button_ratios(), assert_zaap_timings_unchanged(), AtlasClient, AtlasSettings (+19 more)

### Community 55 - "Community 55"
Cohesion: 0.09
Nodes (33): activity_flags(), audit_live_page(), base_result(), build_audit(), inspect(), clean_tokens(), compare_images(), compare_objects() (+25 more)

### Community 56 - "Community 56"
Cohesion: 0.07
Nodes (3): craft_category_for_item(), CraftPage, CraftMinimalLazyTests

### Community 57 - "Community 57"
Cohesion: 0.09
Nodes (25): GuideUltimeCanonicalDependenciesTests, GuideUltimeCanonicalLockTests, audit(), _audit_critical_supports(), _dependency_files(), _load(), main(), _manifest_support_files() (+17 more)

### Community 58 - "Community 58"
Cohesion: 0.10
Nodes (19): DirectionMacro, clipboard_text(), _configure_keyboard_api(), key_down(), key_up(), press_hotkey(), press_key(), release_common_inputs() (+11 more)

### Community 59 - "Community 59"
Cohesion: 0.10
Nodes (11): _category_order(), DofusGuideCandidate, _guide_id_from_title(), GuideBuildResult, GuideCatalogBuilder, _quest_chain_steps(), _quest_step(), _write_json() (+3 more)

### Community 60 - "Community 60"
Cohesion: 0.11
Nodes (26): _is_ankama_type_url(), _is_sha256(), load_protocol_mapping(), _non_negative_int(), _parse_character_identity(), _parse_finished_quests_snapshot(), _parse_path(), parse_protocol_mapping() (+18 more)

### Community 61 - "Community 61"
Cohesion: 0.12
Nodes (9): GuideActivity, GuideChapter, Guide, GuidePart, GuideRequiredItem, GuideSection, GuideSeries, GuideStep (+1 more)

### Community 62 - "Community 62"
Cohesion: 0.09
Nodes (14): AdventureRouteEngine, visit(), format_route_step(), ItemRequirement, _norm(), OptimizationMetrics, OptimizationWeights, RouteAction (+6 more)

### Community 63 - "Community 63"
Cohesion: 0.10
Nodes (7): GuideUltimeCardState, GuideUltimeGeneratedService, GuideUltimeProgress, _norm(), _read_json(), _safe_int(), GuideUltimeLazyFallbackTests

### Community 64 - "Community 64"
Cohesion: 0.10
Nodes (13): BaseRepository, _decode_json_fields(), ImageRepository, ItemRepository, ItemSetRepository, JobRepository, _legacy_image_url_or_path(), _legacy_item() (+5 more)

### Community 65 - "Community 65"
Cohesion: 0.09
Nodes (10): key(), _env_truthy(), network_debug_enabled(), network_debug_log(), protocol_payload_summary(), _safe_debug_value(), InstrumentedCurrentProtocolCalibration, InstrumentedNetworkProgressBridge (+2 more)

### Community 67 - "Community 67"
Cohesion: 0.07
Nodes (3): item_row(), QuestLine, GuidePhase3Tests

### Community 68 - "Community 68"
Cohesion: 0.08
Nodes (23): CharacterResolution, StaticResolver, _AchievementProgress, _AchievementProvider, _AchievementState, _bridge(), _encode_varint(), _identify() (+15 more)

### Community 69 - "Community 69"
Cohesion: 0.07
Nodes (6): RealEquipmentScenarioTests, DeferredEncyclopediaSmokeTests, RuntimeObservationTests, worker(), compare_runtime_to_graph(), RuntimeObserver

### Community 70 - "Community 70"
Cohesion: 0.13
Nodes (16): _array(), _coord_from_text(), DocumentaryIndex, _explicit_coord(), ForensicAudit, _iter_action_rows(), _iter_final_steps(), main() (+8 more)

### Community 71 - "Community 71"
Cohesion: 0.07
Nodes (5): read_json_validated(), ProfileSettingsService, CriticalJsonSchemaTests, ProfileSettingsServiceTests, ProfileStorageBridgeTests

### Community 72 - "Community 72"
Cohesion: 0.09
Nodes (5): _guide_ui(), QuestDetailView, add(), _Provider, QuestDetailRequirementCacheTests

### Community 73 - "Community 73"
Cohesion: 0.07
Nodes (4): AtlasIntegrityGateTests, run(), run(), FakeExecutor

### Community 74 - "Community 74"
Cohesion: 0.08
Nodes (18): _build_manual_runtime_compact_cache_in_worker(), _cache_identity(), _connect(), DeferredQuestRecord, ensure_lazy_catalog_cache(), _json(), load_network_catalog(), load_quest_name_index() (+10 more)

### Community 75 - "Community 75"
Cohesion: 0.07
Nodes (4): GuideUltimeManualCard, GuideManualContractRowCacheTests, _Service, GuideUltimeManualClickableEntityTests

### Community 76 - "Community 76"
Cohesion: 0.08
Nodes (7): GuidePathResolver, walk(), walk(), build_one(), _loose_name(), mandatory_references(), GuidePrerequisiteLookupTests

### Community 77 - "Community 77"
Cohesion: 0.13
Nodes (38): append_issue_table(), audit_graph(), audit_guides(), audit_images(), audit_progress(), audit_quests(), build_audit(), dir_entry() (+30 more)

### Community 78 - "Community 78"
Cohesion: 0.12
Nodes (27): build_cache_from_providers(), filter_entries_for_world(), get_cache_summary(), get_local_image_files(), get_local_image_stats(), is_default_world_entry(), LocalImageStats, MapCacheSummary (+19 more)

### Community 79 - "Community 79"
Cohesion: 0.09
Nodes (13): cached_scaled_pixmap(), clear_guide_home_image_cache(), get_cached_scaled_pixmap(), store_scaled_pixmap(), _catalog_guide_title(), GuideHomeCard, _progress_label(), _tuple_progress_state() (+5 more)

### Community 80 - "Community 80"
Cohesion: 0.08
Nodes (5): HomePage, _resolve_quest_provider(), _FakeGuideProvider, _FakeManualService, HomeGuideUltimeSourceTests

### Community 81 - "Community 81"
Cohesion: 0.10
Nodes (21): _combine_and(), criterion_alternatives(), walk(), CriterionAlternative, CriterionAtom, mandatory_qf_ids(), qf_alternative_sets(), residual_qf_alternatives() (+13 more)

### Community 82 - "Community 82"
Cohesion: 0.12
Nodes (27): portable_asset_path(), actionable_images(), actionable_rows(), block_content_key(), block_source_url(), build_parser(), checkpoint(), confirmed_pages() (+19 more)

### Community 83 - "Community 83"
Cohesion: 0.10
Nodes (19): build_parser(), DeobfuscationEvidenceValidation, main(), validate_consensus_deobfuscation_reports(), ankama_type_alias(), DeobfuscationMatch, DeobfuscationReport, DeobfuscationReportError (+11 more)

### Community 84 - "Community 84"
Cohesion: 0.12
Nodes (29): SwitchClickContext, SwitchClickMacro, current_cursor_pos(), INPUT, INPUT_UNION, MOUSEINPUT, send_client_click(), _send_mouse_flag() (+21 more)

### Community 85 - "Community 85"
Cohesion: 0.17
Nodes (33): AssetValidation, check_doduda_release_archive(), copy_asset_to_expected_path(), download_file(), expected_world_assets(), ExpectedWorldAsset, extract_matching_worldmap_archive(), find_doduda_executable() (+25 more)

### Community 86 - "Community 86"
Cohesion: 0.08
Nodes (4): _resolve_progressive_quests_page_type(), LazyQuestsPage, test_changed_quest_detail_signature_renders_once_and_caches_result(), QuestInteractionRuntimePatchTests

### Community 87 - "Community 87"
Cohesion: 0.13
Nodes (16): DiscoveryEvidenceCandidate, ProtocolDiscoveryConsensus, audit_mapping_evidence(), audit_payload(), build_parser(), load_consensus(), main(), MappingEvidenceValidation (+8 more)

### Community 88 - "Community 88"
Cohesion: 0.14
Nodes (7): KnownSessionProgressBridge, KnownSessionProtocolMessageDecoder, _positive_int(), _trusted_client_label(), VerifiedKnownSessionRecovery, _DecoderDelegate, KnownSessionRecoveryTests

### Community 89 - "Community 89"
Cohesion: 0.10
Nodes (5): DataStore, migration_for(), TextRepository, DataStoreBackupTests, DataStoreMigrationTests

### Community 90 - "Community 90"
Cohesion: 0.11
Nodes (23): CanonicalToolSpecTests, ToolCatalogTests, _capabilities(), catalog(), _cost_hint(), _derived_side_effects(), _invocation(), _json_cli_flag() (+15 more)

### Community 91 - "Community 91"
Cohesion: 0.06
Nodes (7): ApplicationRuntimeCharacterizationTests, factory(), __init__(), _NavigationPage, _NavigationShell, _NavigationTabBar, _NavigationTabs

### Community 92 - "Community 92"
Cohesion: 0.13
Nodes (29): module_proofs(), build_diff_report(), changed_files(), _changed_test_modules(), _command_for_group(), CommandExecutor, _critical_execution_issues(), _critical_inventory_modules() (+21 more)

### Community 93 - "Community 93"
Cohesion: 0.11
Nodes (6): AchievementCategory, AchievementProvider, achievement_sort_key(), resolve_links(), source_position(), replace()

### Community 94 - "Community 94"
Cohesion: 0.08
Nodes (13): _drop_nested_raw(), _build_compact_guide_cache(), _CompactGuideNoopItemProvider, _dump_compact_default_guides(), _ensure_compact_guide_cache_cli(), ensure_guide_compact_cache(), _entity_index_payload(), _guide_compact_cache_valid() (+5 more)

### Community 95 - "Community 95"
Cohesion: 0.09
Nodes (14): _array(), _coord_from_text(), GuideUltimeRouteAdapter, _safe_coord(), _safe_int(), _safe_map_id(), GuideIntegrityEntrypointsTests, GuideToolCanonicalEntrypointTests (+6 more)

### Community 96 - "Community 96"
Cohesion: 0.11
Nodes (11): AchievementProgressService, achievement_category_name(), achievement_id(), achievement_objectives(), compare(), objective_done(), objective_parts(), ref_group_done() (+3 more)

### Community 97 - "Community 97"
Cohesion: 0.08
Nodes (3): GuideCatalogView, GuideCardDelegate, GuideListModel

### Community 98 - "Community 98"
Cohesion: 0.09
Nodes (9): NetworkBootstrapResult, NetworkControllerStatus, NetworkRuntimeController, _FakeCalibrationController, _FakeRuntime, _FakeRuntimeController, NetworkCatchupLifecycleTests, FakeRuntime (+1 more)

### Community 99 - "Community 99"
Cohesion: 0.12
Nodes (25): _blocking_function_names(), _call_name(), _collect_imports(), _contains_blocking_call(), _controlled_exec_call_ids(), _direct_blocking_call(), _dynamic_import_targets(), _expression_key() (+17 more)

### Community 100 - "Community 100"
Cohesion: 0.09
Nodes (8): _runtime_formatter(), set_debug_logging(), AtlasRuntime, AutoGroupMacro, test_runtime_constructor_does_not_load_settings(), fake_load_settings(), test_runtime_settings_injection_does_not_trigger_disk_load(), test_runtime_settings_load_once_on_first_access()

### Community 101 - "Community 101"
Cohesion: 0.08
Nodes (8): _cancel_pending_future(), _decode_solution_image(), SolutionImageLabel, PerformanceBudgetTests, _CountingExecutor, _PendingFuture, QtAsyncNonAccumulationTests, evaluate_metric()

### Community 102 - "Community 102"
Cohesion: 0.09
Nodes (10): ApiStaticImporter, ExistingCacheImporter, make_config(), ApiStaticImporterTests, CompatibilityAdapterTests, DataStoreTests, ExistingCacheImporterTests, ImportManagerTests (+2 more)

### Community 103 - "Community 103"
Cohesion: 0.08
Nodes (3): AgentVerificationTests, failure(), mutation()

### Community 104 - "Community 104"
Cohesion: 0.10
Nodes (9): ChangeIntelligenceTests, TestCostEvidenceTests, build_change_plan(), _git(), _imports_deleted_module(), removed_python_modules(), stale_removed_imports(), suggest_targeted_test_order() (+1 more)

### Community 105 - "Community 105"
Cohesion: 0.14
Nodes (27): corrupt_source_title_compatible(), source_title_key(), build_verification(), candidate_urls(), canonical_slug(), classify_page_for_quest(), connected_visuals(), distinctive_signals() (+19 more)

### Community 106 - "Community 106"
Cohesion: 0.11
Nodes (11): PhaseCertificationGuardrailsTests, _changed_paths(), _digest(), evaluate_phase(), _guide_certification_errors(), _guide_evidence_completeness_errors(), _is_ancestor(), _load_json() (+3 more)

### Community 107 - "Community 107"
Cohesion: 0.22
Nodes (31): _add_typed_item(), _bool_or_none(), bundle_from_records(), classify_item(), normalize_api_item(), normalize_class_spell_links(), normalize_d2o_item(), normalize_item_conditions() (+23 more)

### Community 108 - "Community 108"
Cohesion: 0.06
Nodes (8): worker(), configure_windows_app_id(), keep_splash_visible(), main(), _resolve_craft_page(), splash_logo_pixmap(), ShellReliabilityTests, priority()

### Community 109 - "Community 109"
Cohesion: 0.15
Nodes (25): AtlasDoctorRuntimeBenchmarkTests, aggregate_samples(), attach_baseline_comparison(), _baseline_medians(), compare_to_baseline(), _current_encyclopedia_page(), current_rss_mb(), _first_achievement_detail() (+17 more)

### Community 110 - "Community 110"
Cohesion: 0.09
Nodes (7): DoctorGraphAuditTests, fixture(), IsolateTriageTests, _domain(), inspect_graph(), _trace_observations(), triage_isolates()

### Community 111 - "Community 111"
Cohesion: 0.15
Nodes (16): AtlasJsonBenchmarkTests, AtlasJsonShardTests, benchmark(), main(), _activate_pointer(), activate_version(), build(), current_directory() (+8 more)

### Community 112 - "Community 112"
Cohesion: 0.07
Nodes (4): GuideUltimeManualView, GuideUltimeManualQuestLinkTests, _ManualQuestLinkService, _QuestProvider

### Community 113 - "Community 113"
Cohesion: 0.13
Nodes (13): _certificate_error(), _character_id_from_key(), install_calibrated_current_profile(), _is_known_legacy_lqn_mapping(), _is_known_legacy_snapshot(), _is_sha256(), _positive_int(), _rollback() (+5 more)

### Community 114 - "Community 114"
Cohesion: 0.12
Nodes (23): achievement_context_section(), achievement_reward_label(), clean_requirement_line(), clear_layout(), _display_item(), format_number(), guides_section(), is_alteration_objective() (+15 more)

### Community 115 - "Community 115"
Cohesion: 0.09
Nodes (4): GuideUltimeRuntimeService, GuideUltimeStableProgressKeyTests, _ProgressKeyService, GuideUltimeV5RuntimeTests

### Community 116 - "Community 116"
Cohesion: 0.17
Nodes (29): active_manifest_path(), append_journal(), apply_validation(), build_parser(), checkpoint(), ensure_backup(), extracted_block_json(), fetch_quest_pages() (+21 more)

### Community 117 - "Community 117"
Cohesion: 0.10
Nodes (7): ProtocolCalibrationBootstrapResult, ProtocolCalibrationController, ProtocolMappingInstallResult, CurrentProtocolSafetyTests, _FakeCalibrationRuntime, _ready_status(), _report()

### Community 118 - "Community 118"
Cohesion: 0.11
Nodes (13): _positive_int(), build_parser(), _character_names_for_slot(), _collector_for_event(), main(), _positive_int(), run_discovery_probe(), ProtocolFieldCandidate (+5 more)

### Community 119 - "Community 119"
Cohesion: 0.10
Nodes (10): install_verified_protocol_mapping(), _rollback_destination(), _is_sha256(), ProtocolMappingRegistry, candidate_payload(), consensus_payload(), NetworkMappingInstallTests, report_text() (+2 more)

### Community 120 - "Community 120"
Cohesion: 0.09
Nodes (9): FileCoverageTests, GraphifyDoctorTests, generate(), reverse_impact(), node_path(), _source_path(), graph_status(), file_coverage() (+1 more)

### Community 121 - "Community 121"
Cohesion: 0.09
Nodes (7): ProtocolCalibrationControllerStatus, _AutoCalibrationFake, _CalibrationFake, NetworkApplicationCoordinatorTests, _ReasonRuntimeFake, _RuntimeFake, _Tabs

### Community 122 - "Community 122"
Cohesion: 0.16
Nodes (18): load_consensus(), build_parser(), load_report(), main(), build_discovery_consensus(), _is_capture_id(), _is_sha256(), _non_negative_int() (+10 more)

### Community 123 - "Community 123"
Cohesion: 0.11
Nodes (12): LiveGraphTests, provider(), change_snapshot(), changed_imports(), _direct_imports(), _git(), handler_factory(), do_GET() (+4 more)

### Community 124 - "Community 124"
Cohesion: 0.16
Nodes (27): acquisition_options(), apply_dungeon_bundle_holds(), apply_universal_class_gate_bridges(), branch_condition_is_common(), conditional_branch_cards(), dungeon_manual_context(), full_success_cards(), full_success_context_for_step() (+19 more)

### Community 125 - "Community 125"
Cohesion: 0.15
Nodes (24): build_row(), build_row_from_values(), candidate_score(), clean_export_dir(), export_image(), export_rank(), export_selected_images(), image_dimensions() (+16 more)

### Community 126 - "Community 126"
Cohesion: 0.13
Nodes (5): ImageIndexer, ImageOrganizer, main(), normalize_text(), ImageIndexerTests

### Community 127 - "Community 127"
Cohesion: 0.13
Nodes (7): CraftResourceDialog, ItemSetDialog, LevelingDialog, RouteDialog, RouteImageLabel, IconCache, AtlasButton

### Community 128 - "Community 128"
Cohesion: 0.17
Nodes (10): full(), plan(), ShadowValidationTests, _actual_required_groups(), aggregate_shadows(), evaluate_shadow(), load_full_report(), campaign() (+2 more)

### Community 130 - "Community 130"
Cohesion: 0.10
Nodes (3): _audit_dispatch(), record(), observed_slot()

### Community 132 - "Community 132"
Cohesion: 0.13
Nodes (8): QuestCompletionInfoDecoder, QuestCompletionInfoRule, _completion_payload(), _Delegate, _field_bytes(), _field_varint(), QuestCompletionInfoDecoderTests, _varint()

### Community 134 - "Community 134"
Cohesion: 0.16
Nodes (5): AtlasDoctorTests, tracking_walk(), _git(), _ast_cache_identity(), run_audit()

### Community 136 - "Community 136"
Cohesion: 0.10
Nodes (10): GuideActionCanonicalTargetTests, GuideActionDropTests, GuideActionFightTests, GuideActionInteractTests, GuideActionModelTests, GuideActionPreparationContractTests, GuideActionQuestLinksTests, GuideActionUseItemTests (+2 more)

### Community 137 - "Community 137"
Cohesion: 0.09
Nodes (4): _FakeManualUiService, _FakeQuestProgress, _FakeQuestProvider, GuideUltimeManualUiNavigationTests

### Community 138 - "Community 138"
Cohesion: 0.09
Nodes (13): _achievement_compact_cache_valid(), _achievement_compact_index_path(), _achievement_compact_source_signature(), _build_compact_cache(), _CompactAchievementSources, ensure_achievement_compact_cache(), _ensure_compact_cache_cli(), achievement_name_index() (+5 more)

### Community 139 - "Community 139"
Cohesion: 0.08
Nodes (10): ActivityBadge, ActivitySummary, CollapsedColumnRail, CompactScroll, EmptyState, EncyclopediaPanel, HideCompletedButton, RequiredItemRow (+2 more)

### Community 140 - "Community 140"
Cohesion: 0.16
Nodes (16): _active_build_sha256(), build_parser(), create_deobfuscation_evidence_bundle(), DeobfuscationEvidenceBundle, DeobfuscationEvidenceBundleError, DeobfuscationReportDigest, _is_sha256(), load_deobfuscation_evidence_bundle() (+8 more)

### Community 141 - "Community 141"
Cohesion: 0.10
Nodes (3): CharacterPage, ModernCharacterPageTests, CharacterPageStatsTests

### Community 142 - "Community 142"
Cohesion: 0.09
Nodes (7): quantity_spinbox(), atlas_application_icon(), AtlasDialog, AtlasDialogHeader, atlas_stylesheet(), CloseActionDialog, UiFoundationTests

### Community 143 - "Community 143"
Cohesion: 0.09
Nodes (14): _await_startup_cache_warmup(), build_craft_preload(), build_guide_progress_preload(), build_preload_payload(), build_quest_preload(), build_quest_related_preload(), guide_progress_state(), _load_quest_characters() (+6 more)

### Community 144 - "Community 144"
Cohesion: 0.14
Nodes (23): _command_tool_paths(), _expression_name(), _git_tracked_paths(), _has_sys_path_mutation(), _is_executable(), _is_wrapper(), _literal_command_tokens(), main() (+15 more)

### Community 145 - "Community 145"
Cohesion: 0.10
Nodes (9): DofusItem, _build_guide_items_index(), _compact_item_payload(), ensure_guide_items_index(), _ensure_guide_items_index_cli(), _guide_item_source_signature(), _iter_doduda_refs(), _read_guide_items_index() (+1 more)

### Community 147 - "Community 147"
Cohesion: 0.12
Nodes (17): _assigned_literal(), classify_root_of_trust_changes(), detect_sensitive_changes(), _find_test_method(), _git_paths(), _has_verification(), _is_constant_assertion(), _literal_expression() (+9 more)

### Community 148 - "Community 148"
Cohesion: 0.14
Nodes (17): result(), VerifiedMainFullReuseTests, event(), jobs(), MainPhaseEvidenceTests, _get_jobs(), main(), verify_event() (+9 more)

### Community 149 - "Community 149"
Cohesion: 0.08
Nodes (6): _FirstIncompleteProbe, GuideUltimeRuntimeProgressCacheTests, _ManualRouteProbe, _RevisionAchievements, _RevisionProgress, _RouteProgressProbe

### Community 150 - "Community 150"
Cohesion: 0.16
Nodes (6): AtlasMetaIntegrityTests, check_ci_contracts(), check_full_discovery_source(), check_zero_baselines(), inspect_critical_test(), validate_inventory()

### Community 151 - "Community 151"
Cohesion: 0.22
Nodes (11): _b(), _idr(), _idz(), _kva(), _kvi(), ProtocolCalibrationTests, _quest(), _Resolver (+3 more)

### Community 152 - "Community 152"
Cohesion: 0.16
Nodes (18): achievement_provider_object_counts(), current_encyclopedia_page(), current_rss_mb(), first_achievement_detail(), first_guide_detail(), git_head(), main(), measure() (+10 more)

### Community 153 - "Community 153"
Cohesion: 0.10
Nodes (4): canonical_manifest_rows(), _FakeAchievementProgress, _FakeQuestProgress, GuideUltimeManualPreviewTests

### Community 154 - "Community 154"
Cohesion: 0.11
Nodes (6): DecodedNetworkEventSource, FakeDecoder, FakeSource, NetworkTransportTests, decode(), decode()

### Community 155 - "Community 155"
Cohesion: 0.14
Nodes (8): Phase8BudgetEvidenceTests, sample(), DeepFirstUseTimingTests, sample(), assess_memory_benchmark(), _nonnegative(), compare_deep_first_use(), _milliseconds()

### Community 156 - "Community 156"
Cohesion: 0.11
Nodes (9): DoctorResourceLifecycleSourceTests, _domain(), export_interactive_graph(), load_snapshot_comparison(), merge_runtime_traces(), save_graph_snapshot(), inspect_resource_lifecycle(), _name() (+1 more)

### Community 157 - "Community 157"
Cohesion: 0.13
Nodes (16): GeneratedFilesGuardTests, RepositoryGitHooksTests, find_forbidden(), find_sensitive_content(), forbidden_reason(), git_paths(), _looks_like_placeholder(), main() (+8 more)

### Community 158 - "Community 158"
Cohesion: 0.16
Nodes (12): _b(), CalibrationRuntimeTests, _idz(), _journal(), _kva(), _kvi(), _LateItemSource, _quest() (+4 more)

### Community 159 - "Community 159"
Cohesion: 0.09
Nodes (4): stop_message_hook(), SyntheticInputGuard, ManagedMouseHook, MouseHook

### Community 160 - "Community 160"
Cohesion: 0.18
Nodes (25): atomic_write_json(), build_craft_list(), cache_api(), _compatibility_adapter(), fetch_recipe_index(), get_cached_image_path(), get_item(), get_item_by_name() (+17 more)

### Community 162 - "Community 162"
Cohesion: 0.10
Nodes (12): ExplainCertificationScopeTests, explain_selection(), build_passport(), compare_passports(), environment(), load_passport(), attach_runtime_trace(), _git() (+4 more)

### Community 163 - "Community 163"
Cohesion: 0.09
Nodes (6): MacroLease, MacroLock, LastClientPoint, _RuntimeCallbackBridge, __init__(), test_runtime_callback_bridge_discards_stale_worker_active_state()

### Community 164 - "Community 164"
Cohesion: 0.09
Nodes (5): LinkService, _AsyncImageDelivery, _decode_guide_image(), _decode_qimage(), _ensure_async_image_delivery()

### Community 165 - "Community 165"
Cohesion: 0.18
Nodes (17): _add_candidate(), _binding_path(), cached_class_icon_path_for_window_name(), cached_dofus_class_key_for_character_name(), clear_organizer_icon_cache(), _client_index_path(), _collect_binding_candidates(), _collect_client_candidates() (+9 more)

### Community 166 - "Community 166"
Cohesion: 0.20
Nodes (16): AtlasDoctorPonytailTests, _git(), severity_counts(), _baseline_text(), _broad_diff_findings(), _classes(), _dependency_findings(), _diff_rows() (+8 more)

### Community 167 - "Community 167"
Cohesion: 0.15
Nodes (8): DoctorScenarioTrendTests, HistoricalTraceComparisonTests, load_scenario_trend(), summarize_scenario_trend(), compare_scenario_traces(), _entered_symbol_names(), load_historical_scenario_diff(), _observed_edges()

### Community 168 - "Community 168"
Cohesion: 0.12
Nodes (5): InterProcessResourceLock, ProgressFileCoordinator, ProgressLockTimeoutError, _hold_resource_lock(), ProgressInterprocessLockingTests

### Community 169 - "Community 169"
Cohesion: 0.10
Nodes (11): catalog_route_map_count_hint(), catalog_route_map_count(), _position_key(), first_position_from_quest(), format_number(), _apply_item_row_state(), _fallback_item_icon(), item_row() (+3 more)

### Community 170 - "Community 170"
Cohesion: 0.12
Nodes (8): GuideProgressCalculator, ProgressCount, GuideStructureRow, _progress_marker(), _progress_state(), solution_header(), _DeferredQuest, GuideProgressDeferredDetailsTests

### Community 171 - "Community 171"
Cohesion: 0.15
Nodes (3): GuideUltimeGeneratedView, _NullAchievementProvider, GuideUltimeRefreshPerformanceTests

### Community 172 - "Community 172"
Cohesion: 0.13
Nodes (5): ProtocolCalibrationRuntime, ProtocolCalibrationStatus, _BlockingProtocolSource, _IdleCalibration, NetworkCalibrationRuntimeStopLifecycleTests

### Community 173 - "Community 173"
Cohesion: 0.12
Nodes (5): CharacterOrderService, remove(), save(), CharacterOrderServiceTests, Row

### Community 174 - "Community 174"
Cohesion: 0.10
Nodes (9): GuideActionAcquisitionTests, GuideActionBuyTests, GuideActionMonsterQuantityTests, GuideActionPositionTests, GuideActionQuantityTests, GuideActionTalkTests, GuideActionTurnInTests, GuideActionTypesCompleteTests (+1 more)

### Community 175 - "Community 175"
Cohesion: 0.13
Nodes (8): LayerBoundaryTests, IntegratedDoctorInvestigationTests, _layer(), layer_boundary_review(), _git_head(), _graph_file_evidence(), investigate_files(), _read_trace()

### Community 176 - "Community 176"
Cohesion: 0.17
Nodes (5): LegacyGuideToolConsumerTests, ToolAuditTests, audit(), _reference_paths(), _tool_paths()

### Community 177 - "Community 177"
Cohesion: 0.11
Nodes (13): _add(), install(), _json_load(), _json_loads(), main(), _norm(), _read_text(), restore() (+5 more)

### Community 178 - "Community 178"
Cohesion: 0.19
Nodes (9): AdapterWarning, AdventureRouteAdapter, AdventureRouteAdapterResult, _array(), _doduda_rows(), _norm(), _safe_int(), RouteCondition (+1 more)

### Community 181 - "Community 181"
Cohesion: 0.10
Nodes (4): EncyclopediaThreePanelDashboard, FixedColumnSplitter, FixedColumnSplitterHandle, EncyclopediaWidgetLazyExportsTests

### Community 182 - "Community 182"
Cohesion: 0.17
Nodes (16): coordinate_pair(), flattened_text_values(), hidden_process_options(), row_coordinate_pair(), row_text_values(), search_tokens(), short_label(), strip_zaap_coordinate_suffix() (+8 more)

### Community 183 - "Community 183"
Cohesion: 0.21
Nodes (10): AgentPlannerTests, build_plan(), choose_work_depth(), _execution_tests(), minimum_integrity_mode(), _planning_catalog(), _preferred_validation_tools(), required_groups() (+2 more)

### Community 185 - "Community 185"
Cohesion: 0.10
Nodes (6): _Calibration, _FailOnceBridge, NetworkRuntimeRobustnessTests, _PartiallyFailingSource, _PassiveBridge, _QueueSource

### Community 186 - "Community 186"
Cohesion: 0.28
Nodes (22): audit(), _before(), _canonical_rows(), _catalog_names(), _error(), _forbid_unconditional(), _load(), main() (+14 more)

### Community 187 - "Community 187"
Cohesion: 0.12
Nodes (4): RelatedPreloadGate, RelatedPreloadState, FaultInjectionContractsTests, RelatedPreloadStateTests

### Community 188 - "Community 188"
Cohesion: 0.10
Nodes (3): DetailPanel, NativeQuestDetailPanel, _LazyCompatQuestDetailPanel

### Community 189 - "Community 189"
Cohesion: 0.20
Nodes (6): FinishedQuestsSnapshotRule, _Delegate, _field_bytes(), _field_varint(), FinishedQuestsSnapshotDecoderTests, _varint()

### Community 190 - "Community 190"
Cohesion: 0.13
Nodes (8): JsonSourceMapping, _fill(), get(), peek(), read_string_span(), read_value_span(), skip_space(), JsonSourceIndexTests

### Community 191 - "Community 191"
Cohesion: 0.19
Nodes (20): _artifact_stamp(), _cached_domain_result(), _expanded_source_files(), _last_json_line(), _load_manifest(), main(), _parse_args(), _path_label() (+12 more)

### Community 192 - "Community 192"
Cohesion: 0.18
Nodes (4): RefactorSimulationTests, _path_uses_symlink(), _runtime_consumer_evidence(), simulate_refactor()

### Community 194 - "Community 194"
Cohesion: 0.14
Nodes (3): AdaptiveCertificationTests, source(), destroyed()

### Community 196 - "Community 196"
Cohesion: 0.15
Nodes (5): FinalQuestStepEvidenceDecoder, _positive_int(), _Delegate, FinalQuestStepEvidenceDecoderTests, _quest()

### Community 197 - "Community 197"
Cohesion: 0.20
Nodes (19): test_build_report_ignores_stale_runtime_ready_from_previous_launch(), test_build_report_merges_launcher_pyside_runtime_and_profile(), test_build_report_tolerates_missing_and_corrupt_files(), test_elapsed_ms_handles_midnight_rollover(), _write(), build_report(), _elapsed_ms(), _format_ms() (+11 more)

### Community 198 - "Community 198"
Cohesion: 0.16
Nodes (7): GuideActionNormalizerTests, GuideIntegrityContractsTests, GuideIntegrityStructuredTests, normalize_action(), _actions(), validate_runtime_lines(), validate_structured_actions()

### Community 199 - "Community 199"
Cohesion: 0.31
Nodes (21): build_index(), _changed_paths(), check_index(), classify_path(), _committed_changed_paths(), committed_tree_sha(), drift_report(), _git() (+13 more)

### Community 200 - "Community 200"
Cohesion: 0.16
Nodes (7): _collect_text(), load_ocre_capture_registry(), ocre_bosses_for_stage(), ocre_capture_lines(), ocre_unlock_policy_lines(), _stage_evidence(), GuideUltimeOcreRegistryRuntimeTests

### Community 202 - "Community 202"
Cohesion: 0.23
Nodes (5): _card_coords(), GuideUltimeWalkthroughCard, _safe_coord(), _strip_sentinel_position(), _valid_position_text()

### Community 203 - "Community 203"
Cohesion: 0.15
Nodes (9): build_parser(), main(), run_probe(), ProtocolDiagnosticsCollector, ProtocolTypeDiagnostic, bytes_field(), encode_varint(), NetworkDiagnosticsTests (+1 more)

### Community 206 - "Community 206"
Cohesion: 0.13
Nodes (12): client_size(), describe_window_row(), _ensure_windows_api(), enumerate_windows(), callback(), hwnd_value(), process_image_path(), callback() (+4 more)

### Community 207 - "Community 207"
Cohesion: 0.17
Nodes (10): AtlasJsonInventoryTests, audit(), audit_local_json(), _contracts(), _decision(), _family(), main(), _referencers() (+2 more)

### Community 208 - "Community 208"
Cohesion: 0.09
Nodes (3): CharacterShellCanonicalTests, __init__(), __init__()

### Community 209 - "Community 209"
Cohesion: 0.19
Nodes (8): details(), GitHubProvenanceTests, zip_passport(), fingerprint(), _api(), check_online(), main(), verify_archive_origin()

### Community 210 - "Community 210"
Cohesion: 0.21
Nodes (17): _achievement(), _evidence(), GuideFinalCoverageCacheTests, cached(), check_after(), check_before(), classify(), collect_route_evidence() (+9 more)

### Community 211 - "Community 211"
Cohesion: 0.12
Nodes (5): _achievement(), _FakeProgressService, _FakeProvider, _LightAchievementsView, OptimizedAchievementsBatchingTests

### Community 212 - "Community 212"
Cohesion: 0.22
Nodes (5): _called_attributes(), _function_node(), _method_node(), PerformanceGuardrailTests, _source()

### Community 215 - "Community 215"
Cohesion: 0.18
Nodes (13): QuestJournalCalibrationEvidence, _b(), _CalibrationFake, _idr(), _kva(), _kvi(), NetworkCalibrationCatchupTests, evidence() (+5 more)

### Community 216 - "Community 216"
Cohesion: 0.11
Nodes (5): _MutexBackend, SingleInstanceGuard, _WindowsMutexBackend, _FakeMutexBackend, SingleInstanceTests

### Community 217 - "Community 217"
Cohesion: 0.16
Nodes (7): AlphaTests, BetaTests, RandomOrderRunnerTests, flatten(), load_tests(), main(), reproducible_suite()

### Community 218 - "Community 218"
Cohesion: 0.20
Nodes (6): GuideActionContractTests, GuideActionDropContractTests, GuideActionNpcGroupingTests, group_consecutive_talks(), GuideActionViolation, validate_actions()

### Community 219 - "Community 219"
Cohesion: 0.18
Nodes (5): load_temporal_registry(), _merge_dict(), _read(), GuideUltimeOcreTemporalLockTests, GuideUltimeTemporalRegistryTests

### Community 220 - "Community 220"
Cohesion: 0.15
Nodes (3): GuideManualProgressBar, SharedGuideManualView, _QuestProvider

### Community 222 - "Community 222"
Cohesion: 0.14
Nodes (3): EquipmentPage, qwebengine_view_class(), EquipmentDeferredStartTests

### Community 223 - "Community 223"
Cohesion: 0.15
Nodes (9): EventPump, _merge_payload(), PreloadReport, PreloadTask, StartupPreloader, worker(), _Pump, _slow_payload() (+1 more)

### Community 224 - "Community 224"
Cohesion: 0.19
Nodes (8): changed_paths(), _git(), main(), plan(), run_parallel_safe(), run_targeted(), SelectionError, _write_report()

### Community 225 - "Community 225"
Cohesion: 0.18
Nodes (6): DevelopmentPreflightTests, DevelopmentPreflightContracts, development_preflight(), _review_python_sources(), _run_focused_tests(), _select_modules()

### Community 226 - "Community 226"
Cohesion: 0.18
Nodes (7): CIHistoryTests, actions_job_step_profile(), application_log_profile(), duplicate_unittest_modules(), main(), report_from_files(), _timestamp()

### Community 227 - "Community 227"
Cohesion: 0.18
Nodes (7): GuidePlayerContractTests, audit(), _issue(), line_contract_issues(), main(), stage_contract_issues(), _talk_target()

### Community 229 - "Community 229"
Cohesion: 0.13
Nodes (4): ProgressState, AchievementSummaryWidget, AchievementListModel, ResultList

### Community 232 - "Community 232"
Cohesion: 0.13
Nodes (4): image_src_from_attrs(), MetaParser, MiniHTMLParser, TokenParser

### Community 234 - "Community 234"
Cohesion: 0.18
Nodes (5): CurrentProtocolCalibration, _is_sha256(), _PendingJournalState, _positive_int(), _SessionCalibrationState

### Community 235 - "Community 235"
Cohesion: 0.28
Nodes (8): QuestJournalRule, _active(), _b(), _finished(), _packed(), QuestJournalDecoderTests, _v(), _varint()

### Community 237 - "Community 237"
Cohesion: 0.19
Nodes (11): build_graph(), commands(), detect(), install_graphify(), main(), _tool_environment(), _is_guide_ultime_candidate(), main() (+3 more)

### Community 238 - "Community 238"
Cohesion: 0.23
Nodes (8): AgentTaskProfileTests, infer_task_type(), load_config(), main(), _quality_rank(), route_for_task(), select_work_card(), TaskProfileError

### Community 239 - "Community 239"
Cohesion: 0.20
Nodes (5): DevEventTests, dev_event(), _git(), _name_status_z(), _normalized()

### Community 240 - "Community 240"
Cohesion: 0.24
Nodes (4): CumulativeCertificationTests, git(), assess_cumulative(), _git()

### Community 241 - "Community 241"
Cohesion: 0.29
Nodes (4): EvidenceClosureTests, git(), _git(), inspect_previous_evidence()

### Community 242 - "Community 242"
Cohesion: 0.19
Nodes (6): GuideUltimeActionQualityAuditTests, audit(), _contains_token(), _issue(), _line_issues(), main()

### Community 243 - "Community 243"
Cohesion: 0.23
Nodes (9): PhaseAdaptiveGateTests, plan(), choose_route(), critical_changed(), _git(), _load(), main(), _save() (+1 more)

### Community 245 - "Community 245"
Cohesion: 0.12
Nodes (5): EncyclopediaService, explicit_provider_callable(), worker(), _GuideStagePayload, test_encyclopedia_uses_indexed_guide_provider_by_default()

### Community 247 - "Community 247"
Cohesion: 0.22
Nodes (9): _clean(), discover_guides(), _fetch_text(), import_guides(), _job_from_title(), main(), parse_guide(), _parse_name_quantity() (+1 more)

### Community 248 - "Community 248"
Cohesion: 0.18
Nodes (5): AiContextTests, _commit_all(), _context_map_lists(), _git(), _git_path_exists()

### Community 249 - "Community 249"
Cohesion: 0.16
Nodes (4): DoctorConsumerSiteTests, _candidate_files(), inspect_consumer_sites(), _literal_string()

### Community 250 - "Community 250"
Cohesion: 0.19
Nodes (9): GuideIntegrityTests, GuideTransversalCanonicalEntrypointTests, _check(), checks_for_mode(), GuideCheck, main(), _render_summary(), run() (+1 more)

### Community 251 - "Community 251"
Cohesion: 0.14
Nodes (6): GuideToolsCliTests, GuideToolsDoctorTests, GuideToolsFacadeStatusTests, GuideToolsStatusRetiredTests, main(), doctor()

### Community 252 - "Community 252"
Cohesion: 0.15
Nodes (4): _AchievementProgress, _AchievementProvider, GuideUltimeSuccessLinkTests, _Service

### Community 255 - "Community 255"
Cohesion: 0.18
Nodes (3): compile(), QuestDetailsTests, compile()

### Community 256 - "Community 256"
Cohesion: 0.24
Nodes (4): _clear_connected_background_qrgb(), clear_connected_dark_background(), _is_background_rgb(), SplashImageTests

### Community 258 - "Community 258"
Cohesion: 0.25
Nodes (4): ScenarioCoverageTests, observed_entered_symbols(), observed_executing_python_files(), summarize_scenarios()

### Community 260 - "Community 260"
Cohesion: 0.14
Nodes (3): EncyclopediaDemandLoadingTests, _PageProbe, _Tabs

### Community 261 - "Community 261"
Cohesion: 0.33
Nodes (7): _active(), _b(), _finished(), QuestSnapshotDiscoveryTests, _snapshot(), _v(), _varint()

### Community 262 - "Community 262"
Cohesion: 0.15
Nodes (5): _bare_runtime(), test_emergency_stop_does_not_materialize_unused_macros(), test_emergency_stop_resets_only_materialized_macros(), test_first_property_access_builds_macro_once_and_reuses_it(), test_macro_property_setter_preserves_test_and_runtime_injection()

### Community 263 - "Community 263"
Cohesion: 0.17
Nodes (10): changed_paths(), classify_diff(), main(), _path_has_direct_test_coverage(), _run_scoped_modules(), ScopeError, contract_plan(), execute_scenarios() (+2 more)

### Community 266 - "Community 266"
Cohesion: 0.33
Nodes (3): main(), ZaapImporter, ZaapImporterTests

### Community 269 - "Community 269"
Cohesion: 0.32
Nodes (11): _b(), _idr(), _idz(), _kva(), _kvi(), _message(), NetworkDirectionGuardTests, _quest() (+3 more)

### Community 273 - "Community 273"
Cohesion: 0.33
Nodes (11): all_named_quests(), build_route(), catalog_unavailable_report(), completed_alternative_satisfied(), _flatten_strings(), load_json(), main(), prerequisite_target() (+3 more)

### Community 274 - "Community 274"
Cohesion: 0.15
Nodes (6): __getattr__(), __getattr__(), _LazyQuestGraphServiceMeta, _load_quest_graph_service_class(), __getattr__(), __getattr__()

### Community 275 - "Community 275"
Cohesion: 0.20
Nodes (5): Reward, _reward_from_dict(), AchievementRewardWidget, RewardCard, LazyEncyclopediaPublicPackagesTests

### Community 276 - "Community 276"
Cohesion: 0.24
Nodes (9): _apply_stage_patch(), _expand_route_hooks(), _insert_anchored_stage(), _load_manual_chapter_uncached(), _merge_sequence(), _read_json(), _route_file_path(), _route_hook_ids() (+1 more)

### Community 277 - "Community 277"
Cohesion: 0.26
Nodes (12): audit_from_local_guide(), duffus_url_for_guide(), extract_page_title(), fetch_text(), guide_id_from_url(), main(), route_sort_key(), sitemap_guide_urls() (+4 more)

### Community 278 - "Community 278"
Cohesion: 0.27
Nodes (4): validate_consensus_deobfuscation(), consensus(), NetworkDeobfuscationAuditTests, report_text()

### Community 279 - "Community 279"
Cohesion: 0.14
Nodes (4): ElevatedHelperProcess, launch_elevated_capture_helper(), _ShellExecuteInfoW, WindowsElevatedHelperProcess

### Community 282 - "Community 282"
Cohesion: 0.18
Nodes (4): OrganizerPage, _resolve_equipment_page(), _resolve_organizer_page(), OrganizerShutdownGuardTests

### Community 283 - "Community 283"
Cohesion: 0.24
Nodes (8): _output_from_environment(), StartupTimeline, _clock(), test_disabled_startup_timeline_has_no_disk_side_effect(), test_future_interpreter_baseline_falls_back_to_current_clock(), test_startup_timeline_flushes_one_json_line(), test_startup_timeline_records_first_occurrence_and_deltas(), test_startup_timeline_uses_interpreter_baseline()

### Community 284 - "Community 284"
Cohesion: 0.34
Nodes (14): Ensure-Pip(), Ensure-Python(), Ensure-PythonModules(), Install-PythonFallback(), Install-WingetPackage(), Invoke-HiddenProcess(), Refresh-ProcessPath(), Resolve-Python313() (+6 more)

### Community 285 - "Community 285"
Cohesion: 0.29
Nodes (9): build_ai_report(), _compact_integrity(), _compact_io_trace(), _compact_live(), _compact_performance(), compare_performance(), compare_runs(), _flatten_numeric() (+1 more)

### Community 287 - "Community 287"
Cohesion: 0.16
Nodes (4): _DummyGuidesView, GuidesHiddenHomeRefreshTests, _GuideUltimeView, _QuestProgress

### Community 288 - "Community 288"
Cohesion: 0.30
Nodes (7): _b(), _kva(), _kvi(), OfflineQuestReconciliationTests, _snapshot(), _v(), _varint()

### Community 290 - "Community 290"
Cohesion: 0.26
Nodes (6): character_id_from_key(), character_key(), is_character_key(), _AchievementStagePayload, worker(), CharacterIdentityContractTests

### Community 291 - "Community 291"
Cohesion: 0.24
Nodes (8): build_related_encyclopedia_data(), RelatedEncyclopediaData, _run_compact_preload_worker(), _warm_achievement_catalogue(), _warm_achievement_source_indexes(), _warm_guide_catalogue(), _warm_guide_files(), _warm_guide_items_index()

### Community 293 - "Community 293"
Cohesion: 0.36
Nodes (6): full_calibration_capabilities_ready(), missing_full_calibration_capabilities(), missing_runtime_capabilities(), _normalized_events(), runtime_capabilities_ready(), NetworkCapabilityContractTests

### Community 297 - "Community 297"
Cohesion: 0.18
Nodes (5): _DummyGuidesView, GuidesBatchProgressTests, _ProgressService, _Scroll, _ScrollBar

### Community 298 - "Community 298"
Cohesion: 0.31
Nodes (3): consensus_payload(), NetworkReadinessAuditTests, report_text()

### Community 299 - "Community 299"
Cohesion: 0.26
Nodes (10): TargetedMutationTests, execute(), _expect_value_error(), _identity_padding(), _identity_positive(), _identity_prefix(), _json_corruption_backup(), _json_missing_copy() (+2 more)

### Community 302 - "Community 302"
Cohesion: 0.22
Nodes (3): CaptureIpcError, FramedJsonConnection, worker()

### Community 303 - "Community 303"
Cohesion: 0.19
Nodes (5): calibrate_zaap_button_from_mouse(), format_zaap_click_position(), location_icon(), lock_icon(), enable_dpi_awareness()

### Community 304 - "Community 304"
Cohesion: 0.29
Nodes (3): ImageDownloader, main(), ImageDownloaderTests

### Community 305 - "Community 305"
Cohesion: 0.21
Nodes (7): character_icon_path(), _ensure_runtime(), __init__(), on_global_character_changed(), persist_selected_character(), sync_selected_character_to_pages(), key()

### Community 306 - "Community 306"
Cohesion: 0.31
Nodes (4): _connected_source(), ElevatedCaptureControlBufferTests, _FakeConnection, _message()

### Community 307 - "Community 307"
Cohesion: 0.15
Nodes (4): _CompactAchievementProvider, _GuideProvider, MemoryBoundAchievementProgressTests, _QuestProgress

### Community 309 - "Community 309"
Cohesion: 0.21
Nodes (4): _achievement_name_index(), IndexedGuideProvider, add_achievement(), test_indexed_guide_provider_reuses_hot_achievement_provider()

### Community 310 - "Community 310"
Cohesion: 0.24
Nodes (4): _LazyAchievementProviderMeta, _LazyGuideProviderMeta, _load_achievement_provider_class(), _load_guide_provider_class()

### Community 311 - "Community 311"
Cohesion: 0.24
Nodes (5): lazy_achievement_progress_service(), lazy_guide_progress_service(), LazyProgressService, _load_achievement_progress(), _load_guide_progress()

### Community 312 - "Community 312"
Cohesion: 0.24
Nodes (3): _FailIfCalled, OptimizedAchievementsRefreshTests, _ProgressProbe

### Community 313 - "Community 313"
Cohesion: 0.18
Nodes (5): decode_scaled_image(), install_guide_image_runtime_policy(), decode_guide_image(), decode_solution_image(), test_guide_decode_never_keeps_full_source_raster()

### Community 316 - "Community 316"
Cohesion: 0.18
Nodes (4): refresh_visible_encyclopedia_widgets(), _EncyclopediaFake, _OtherWidget, _VisibleChild

### Community 318 - "Community 318"
Cohesion: 0.32
Nodes (4): DoctorCapabilityContractsTests, _call_names(), capability_inventory(), _test_case_defined()

### Community 319 - "Community 319"
Cohesion: 0.26
Nodes (4): AtlasLifecycleSoakTests, execute(), _flatten(), main()

### Community 321 - "Community 321"
Cohesion: 0.35
Nodes (3): archived(), plan(), ShadowCampaignTests

### Community 324 - "Community 324"
Cohesion: 0.17
Nodes (4): ComparablePreloadCacheIsolationTests, DeepAchievementTimingContractTests, DeepQuestTimingContractTests, QuestSourcePhaseProfilingContractTests

### Community 326 - "Community 326"
Cohesion: 0.24
Nodes (7): _cached_criterion_references(), _criterion_branches(), parse(), CriterionBranch, _deduplicate_branches(), _split_top(), _strip_outer_parentheses()

### Community 328 - "Community 328"
Cohesion: 0.31
Nodes (4): clear_quest_character_cache(), QuestCharacterCacheTests, fake_loader(), _write()

### Community 335 - "Community 335"
Cohesion: 0.38
Nodes (3): IndependentAuthorityTests, protected(), same_blobs()

### Community 337 - "Community 337"
Cohesion: 0.22
Nodes (3): GuideUltimeLightweightAchievementIndexTests, _LoadedProvider, _UnloadedProvider

### Community 338 - "Community 338"
Cohesion: 0.25
Nodes (3): achievement(), FakeAchievementProvider, FakeQuestProvider

### Community 339 - "Community 339"
Cohesion: 0.20
Nodes (4): _class_methods(), test_only_shared_guide_classes_own_visual_composition(), test_shared_renderer_is_guide_agnostic(), test_sylvestre_has_no_dedicated_ui_file_or_class()

### Community 340 - "Community 340"
Cohesion: 0.24
Nodes (5): main(), main(), __init__(), active_observer(), main()

### Community 341 - "Community 341"
Cohesion: 0.20
Nodes (6): classify_domains(), historical_evidence_usable(), plan(), _required_boundary_modules(), _safe_paths(), verify_scoped_evidence()

### Community 342 - "Community 342"
Cohesion: 0.36
Nodes (7): catalog_index(), coverage_names(), load(), main(), route_field_errors(), route_quest_names(), walk()

### Community 343 - "Community 343"
Cohesion: 0.31
Nodes (3): derive_completion_state(), _safe_int(), AchievementProgressLogicTests

### Community 344 - "Community 344"
Cohesion: 0.33
Nodes (5): QuestCategoryGroup, QuestHierarchy, QuestHierarchyPath, QuestSeries, QuestHierarchyMemoryTests

### Community 348 - "Community 348"
Cohesion: 0.38
Nodes (4): QuestSourceError, GuideUltimeCatalogFailureTests, load_provider_achievements(), load_provider_quests()

### Community 349 - "Community 349"
Cohesion: 0.27
Nodes (4): SourceImpactTests, _safe_relative(), source_reverse_impact(), _tracked_python()

### Community 350 - "Community 350"
Cohesion: 0.20
Nodes (3): CharacterHotkeyMappingTests, __init__(), __init__()

### Community 353 - "Community 353"
Cohesion: 0.38
Nodes (4): metric_payload(), Phase8MemoryAdvisoryPolicyTests, run_validation(), validation_code()

### Community 356 - "Community 356"
Cohesion: 0.29
Nodes (3): _FailIfCalled, _ProgressProbe, QuestsExternalProgressRefreshTests

### Community 359 - "Community 359"
Cohesion: 0.36
Nodes (6): achievement_quest_ids(), add_achievement(), add_quest(), add_references(), root_achievement_quest_ids(), safe_int()

### Community 360 - "Community 360"
Cohesion: 0.47
Nodes (6): build_report(), documentary_text_count(), legacy_visual_count(), main(), markdown_report(), read_json()

### Community 363 - "Community 363"
Cohesion: 0.25
Nodes (4): FocusedFunctionInventoryTests, compare_source_functions(), _functions(), visit()

### Community 364 - "Community 364"
Cohesion: 0.31
Nodes (4): DoctorIntegrityTimeoutTests, _decode_lines(), _read_gate_progress(), run_integrity_gate()

### Community 365 - "Community 365"
Cohesion: 0.28
Nodes (4): CriticalCoverageTests, execute(), load_policy(), main()

### Community 368 - "Community 368"
Cohesion: 0.44
Nodes (3): GuideUltimeIvoireExitInteractionsTests, _stage(), _texts()

### Community 370 - "Community 370"
Cohesion: 0.33
Nodes (4): _ReloadProbe, test_changed_guide_ultime_progress_refreshes_once_and_marks_signature(), test_unchanged_guides_external_progress_returns_before_any_work(), _ViewProbe

### Community 373 - "Community 373"
Cohesion: 0.32
Nodes (3): ensure_placeholder_asset(), load_map_pixmap(), resolve_asset_path()

### Community 375 - "Community 375"
Cohesion: 0.50
Nodes (5): achievement_row(), build_audit(), file_evidence(), main(), markdown_report()

### Community 376 - "Community 376"
Cohesion: 0.39
Nodes (6): build_audit(), enriched_visual_rows(), main(), markdown_report(), relative(), resolved_path()

### Community 378 - "Community 378"
Cohesion: 0.29
Nodes (4): empty_detail_html(), _render_static_theme_template(), render_theme_template(), _render_theme_template()

### Community 380 - "Community 380"
Cohesion: 0.36
Nodes (4): check_environment(), compile_script(), _elapsed_ms(), main()

### Community 393 - "Community 393"
Cohesion: 0.29
Nodes (3): _cycle_components(), visit(), key()

### Community 403 - "Community 403"
Cohesion: 0.52
Nodes (3): GuideFullSuiteFixtureBudgetTests, _method_calls(), _slow_method()

### Community 412 - "Community 412"
Cohesion: 0.33
Nodes (5): obligations(), _triggered(), affected_groups(), classify_risk(), _matches()

### Community 413 - "Community 413"
Cohesion: 0.43
Nodes (5): _api(), assess_policy_authority(), check_online(), blobs(), main()

### Community 420 - "Community 420"
Cohesion: 0.33
Nodes (3): _apply_saved_progress(), _manual_route_stage_total(), _persisted_manual_summary()

### Community 431 - "Community 431"
Cohesion: 0.60
Nodes (5): _source(), test_combat_rows_use_neutral_translucent_shared_style(), test_detached_combat_fallback_is_gone(), test_lanyel_position_deduplication_is_part_of_shared_renderer(), test_progress_strip_is_built_before_scroll_and_bottom_navigation()

### Community 437 - "Community 437"
Cohesion: 0.53
Nodes (3): execute(), load_inventory(), main()

### Community 438 - "Community 438"
Cohesion: 0.60
Nodes (4): _cached_mandatory_references(), parse(), split_top(), strip_outer()

### Community 441 - "Community 441"
Cohesion: 0.70
Nodes (5): dofus_window_from_point(), client_screen_rect(), contains(), enum_callback(), window_screen_rect()

### Community 444 - "Community 444"
Cohesion: 0.70
Nodes (4): _fake(), test_changed_character_sources_reload_once_and_publish_signature(), test_empty_character_state_is_reloaded_even_with_same_signature(), test_unchanged_character_sources_skip_legacy_reload()

### Community 454 - "Community 454"
Cohesion: 0.80
Nodes (4): Invoke-GuideTestOrReuse(), Invoke-LoggedNative(), Invoke-PythonCheck(), Write-LogLine()

## Knowledge Gaps
- **13 isolated node(s):** `_HotkeyWindowMixin`, `_PcapInterface`, `_PcapPacketHeader`, `_Sockaddr`, `_SockaddrIn` (+8 more)
  These have ≤1 connection - possible missing edges. (Counts symbols only; 2686 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **187 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `load_temporal_registry()` connect `Community 219` to `Community 0`, `Community 41`, `Community 11`, `Community 342`, `Community 186`?**
  _High betweenness centrality (0.027) - this node is a cross-community bridge._
- **Why does `AchievementsView` connect `Community 19` to `Community 0`, `Community 1`, `Community 129`, `Community 2`, `Community 383`, `Community 50`, `Community 211`, `Community 181`, `Community 312`, `Community 28`, `Community 29`, `Community 127`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **Why does `QuestCatalog` connect `Community 2` to `Community 0`, `Community 1`, `Community 131`, `Community 4`, `Community 5`, `Community 13`, `Community 269`, `Community 151`, `Community 409`, `Community 27`, `Community 158`, `Community 288`, `Community 291`, `Community 37`, `Community 39`, `Community 40`, `Community 41`, `Community 43`, `Community 46`, `Community 432`, `Community 49`, `Community 51`, `Community 55`, `Community 66`, `Community 67`, `Community 196`, `Community 68`, `Community 74`, `Community 77`, `Community 80`, `Community 338`, `Community 86`, `Community 215`, `Community 98`, `Community 105`, `Community 234`, `Community 236`, `Community 114`, `Community 371`, `Community 116`, `Community 117`, `Community 255`?**
  _High betweenness centrality (0.023) - this node is a cross-community bridge._
- **What connects `_HotkeyWindowMixin`, `_PcapInterface`, `_PcapPacketHeader` to the rest of the system?**
  _13 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Community 0` be split into smaller, more focused modules?**
  _Cohesion score 0.024313891634891494 - nodes in this community are weakly interconnected._
- **Should `Community 1` be split into smaller, more focused modules?**
  _Cohesion score 0.03824904377390565 - nodes in this community are weakly interconnected._
- **Should `Community 2` be split into smaller, more focused modules?**
  _Cohesion score 0.027126436781609194 - nodes in this community are weakly interconnected._