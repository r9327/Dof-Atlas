import ast,hashlib,importlib.util,json,os,subprocess,sys,tempfile,tracemalloc
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/workspace/Dof-Atlas'); OUT=Path('/workspace/audit-atlas/evidence')
sys.path.insert(0,str(ROOT))
import tests
results={}
from app.modules.encyclopedia.services.guide_progress_service import GuideProgressService
from app.modules.encyclopedia.services.serialized_achievement_progress_service import AchievementProgressService
with tempfile.TemporaryDirectory() as d:
 for label,cls,method,args in [('guide',GuideProgressService,'set_manual_step_completed',('character:1','guide','stage',True)),('achievement',AchievementProgressService,'set_achievement_completed',('character:1',123,True))]:
  p=Path(d)/(label+'.json');s=cls(p)
  code=f'from {cls.__module__} import {cls.__name__}; from pathlib import Path; s={cls.__name__}(Path({str(p)!r})); s.{method}(*{args!r})'
  sub=subprocess.run([sys.executable,'-c',code],cwd=ROOT,capture_output=True,text=True)
  before=json.loads(p.read_text());s.save();after=json.loads(p.read_text())
  results['external_snapshot_'+label]={'child_exit':sub.returncode,'before':before,'after':after,'lost_external_state':before!=after}
from local_dofus_data.utils import detect_encoding
path=ROOT/'data/encyclopedia/quests/quests_enriched.json'
tracemalloc.start();value=detect_encoding(path);_,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
results['encoding_probe']={'encoding':value,'file_bytes':path.stat().st_size,'peak_tracemalloc_bytes':peak,'note':'one diagnostic invocation, not application RSS/startup benchmark'}
from app.modules.encyclopedia.providers.dofus_item_provider import _read_guide_items_index
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'cache.json';p.write_text('{"schema_version":"broken"}')
 try:_read_guide_items_index(path=p);result='fallback'
 except Exception as e:result=type(e).__name__+': '+str(e)
 results['guide_item_cache_recovery']=result
from app.pages.equipment_page import EquipmentPage
messages=[];view=EquipmentPage(messages.append)
with patch('app.pages.equipment_page.QDesktopServices.openUrl',return_value=False):view.open_huzounet()
results['external_browser_failure']={'openUrl':False,'status':messages};view.deleteLater()
validators=[]
paths=subprocess.check_output(['git','ls-files','--','app/network/*.py'],cwd=ROOT,text=True).splitlines()
for filename in paths:
 tree=ast.parse((ROOT/filename).read_text())
 for node in ast.walk(tree):
  if isinstance(node,ast.FunctionDef) and node.name=='_is_sha256':
   node.decorator_list=[];scope={};exec(compile(ast.Module(body=[node],type_ignores=[]),filename,'exec'),scope)
   malformed='aa'+' '*60+'bb'
   validators.append({'path':filename,'line':node.lineno,'accepts_embedded_whitespace':scope['_is_sha256'](malformed),'decoded_bytes':len(bytes.fromhex(malformed))})
results['sha256_validators']=validators
from app.cartography import world_db,map_view_manifest
with tempfile.TemporaryDirectory() as d, patch.object(world_db,'WORLD_DB_PATH',Path(d)/'world.db'):
 p=Path(d)/'manifest.json';p.write_text(json.dumps({'views':[{'view_key':'audit_view','name':'Audit fixture','maps':[{'x':1,'y':2}]}]}))
 map_view_manifest.import_map_view_manifest(p);world_db.set_current_map('audit_view',1,2)
 before=world_db.get_maps_for_view('audit_view');summary=map_view_manifest.import_map_view_manifest(p);after=world_db.get_maps_for_view('audit_view')
 results['world_reimport']={'before':[{k:r[k] for k in ('status','scan_count','last_seen_at')} for r in before],'after':[{k:r[k] for k in ('status','scan_count','last_seen_at')} for r in after],'summary':summary,'note':'explicit import API, no evidence of automatic startup invocation'}
 p.write_text(json.dumps({'views':[{'view_key':'audit_view','name':'Audit fixture','maps':[{'x':1,'y':2},{'x':3,'y':4,'status':'verified','polygon':object.__name__}],'links':[{'target_view_key':'missing_target'}]}]}))
 results['world_reference_validator']=map_view_manifest.load_manifest(p)[1]
from app import storage
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'zaap.json';p.write_text('{"zaap_button":{"x_ratio":0.1,"y_ratio":0.2}}')
 real=storage.read_zaap_shortcuts;count=0
 def interleaved(path=None):
  global count
  payload=real(path);count+=1
  if count==1:storage.save_zaap_button_ratios(.7,.8,p)
  return payload
 with patch.object(storage,'read_zaap_shortcuts',side_effect=interleaved):storage.save_zaap_favorites(['Bonta'],[{'name':'Bonta'}],p)
 results['zaap_interleaved_writes']={'expected_ratios':[.7,.8],'actual':json.loads(p.read_text()),'note':'deterministic concurrent-writer interleaving; ordinary single UI event sequencing does not reproduce this race'}
pr=Path('/workspace/audit-atlas/pr159')
spec=importlib.util.spec_from_file_location('audit_user_data',pr/'app/distribution/user_data.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as d:
 d=Path(d);legacy=d/'legacy';(legacy/'data/encyclopedia/progress').mkdir(parents=True);(legacy/'DOFUS.bat').write_text('@echo off')
 for n in ('guide_progress.json','achievement_progress.json'):(legacy/'data/encyclopedia/progress'/n).write_text('{"saved":true}')
 (legacy/'data/dofus_atlas_world.db').write_bytes(b'audit world fixture');exe=d/'versions/v1/AtlasApp/AtlasApp.exe';exe.parent.mkdir(parents=True);exe.write_bytes(b'MZ');user=d/'user';m.prepare_user_data(exe,user,legacy)
 results['pr159_migration_missing']={p: (user/p).exists() for p in ('data/encyclopedia/progress/guide_progress.json','data/encyclopedia/progress/achievement_progress.json','data/dofus_atlas_world.db')}
 env=os.environ.copy();env['DOFUS_ATLAS_USER_ROOT']=str(user)
 code='import json;from app.constants import QUEST_PROGRESS_FILE,DATA_DIR;from app.modules.encyclopedia.services.guide_progress_service import GUIDE_PROGRESS_FILE;from app.modules.encyclopedia.services.serialized_achievement_progress_service import ACHIEVEMENT_PROGRESS_FILE;from app.cartography.world_db import WORLD_DB_PATH;from local_dofus_data.config import DEFAULT_CONFIG;print(json.dumps({k:str(v) for k,v in locals().copy().items() if k.endswith("FILE") or k in ("DATA_DIR","WORLD_DB_PATH")}));print(DEFAULT_CONFIG.sqlite_path)'
 sub=subprocess.run([sys.executable,'-c',code],cwd=pr,env=env,capture_output=True,text=True);results['pr159_actual_persistence_paths']={'exit':sub.returncode,'stdout':sub.stdout,'stderr':sub.stderr}
(OUT/'reproductions.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
