import ast,csv,hashlib,json,re,subprocess,sys
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path('/workspace/Dof-Atlas'); OUT=Path('/workspace/audit-atlas/evidence');sys.path.insert(0,str(ROOT))
from tools.atlas_doctor_lib.graph_audit import inspect_graph
from tools.atlas_doctor_lib.resource_lifecycle import inspect_resource_lifecycle
g=json.load(open(ROOT/'graphify-out/graph.json'));nodes={n['id']:n for n in g['nodes']};adj=defaultdict(list);com=defaultdict(list)
for e in g['links']:
 adj[e['source']].append({'direction':'export_source','neighbor':e['target'],'relation':e.get('relation'),'confidence':e.get('confidence')})
 adj[e['target']].append({'direction':'export_target','neighbor':e['source'],'relation':e.get('relation'),'confidence':e.get('confidence')})
for n in nodes.values():com[n.get('community')].append(n)
allrows=[]
for i,n in enumerate(nodes.values(),1):
 allrows.append(dict(id=f'GN-{i:05}',graph_id=n['id'],symbol=n.get('label'),file=n.get('source_file'),location=n.get('source_location'),community=n.get('community'),degree=len(adj[n['id']]),connections=adj[n['id']],status='NON CONFIRMÉ',decision='CONSERVER; no dead-code conclusion from graph alone'))
(OUT/'graph-nodes.json').write_text(json.dumps(allrows,ensure_ascii=False,indent=2))
first=inspect_graph(g,root=ROOT);limits=first['limits'];print(limits)
weak=[];orphan=[];isolated=[]
for offset in range(0,max(limits['weak_total'],limits['orphan_total'],limits['community_total']),30):
 p=inspect_graph(g,root=ROOT,weak_offset=offset,community_offset=offset,orphan_offset=offset)
 weak+=p['weak_production_candidates'];orphan+=p['orphan_nodes'];isolated+=p['isolated_communities']
refs=json.load(open(OUT/'name-references.json'))
for r in weak:
 name=r['symbol'].lstrip('.').removesuffix('()');r['ast_name_references']=refs.get(name,[]);r['binding_proven']=False
(OUT/'graph-all-candidates.json').write_text(json.dumps(dict(weak=weak,orphan=orphan,isolated_communities=isolated,limits=limits),ensure_ascii=False,indent=2))
communityrows=[]
for k,ns in com.items():
 fs=sorted({n.get('source_file','') for n in ns});prod=[f for f in fs if f.startswith(('app/','local_dofus_data/')) or f=='main.py'];internal=external=0;cross=Counter()
 for n in ns:
  for e in adj[n['id']]:
   other=nodes[e['neighbor']];oc=other.get('community')
   if oc==k:internal+=1
   else:external+=1;cross[str(oc)]+=1
 communityrows.append(dict(id=f'GC-{k}',community=k,files=fs,production_files=prod,nodes=[n['id'] for n in ns],internal_edges=internal//2,external_edges=external,cross_communities=dict(cross),decision='CONSERVER; domain cohesion needs semantic consumer proof, Leiden membership is advisory',status='NON CONFIRMÉ'))
(OUT/'graph-communities.json').write_text(json.dumps(communityrows,ensure_ascii=False,indent=2))
paths=[p for p in subprocess.check_output(['git','ls-files','--','*.py'],cwd=ROOT,text=True).splitlines() if p.startswith(('app/','local_dofus_data/')) or p=='main.py']
life=[]
for i in range(0,len(paths),8):life.append(inspect_resource_lifecycle(ROOT,paths[i:i+8]))
(OUT/'resource-lifecycle-all.json').write_text(json.dumps(life,ensure_ascii=False,indent=2))
tracked=subprocess.check_output(['git','ls-files','--','*.json'],cwd=ROOT,text=True).splitlines();rows=[];all_dup=[]
for filename in tracked:
 duplicates=[];nonfinite=[]
 def pairs(ps):
  d={}
  for k,v in ps:
   if k in d:duplicates.append(k)
   d[k]=v
  return d
 try:
  data=json.loads((ROOT/filename).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda x:nonfinite.append(x) or x)
  row=dict(path=filename,parse='PASS',duplicate_keys=duplicates,non_finite=nonfinite,sha256=hashlib.sha256((ROOT/filename).read_bytes()).hexdigest(),root_type=type(data).__name__)
 except Exception as e:row=dict(path=filename,parse='FAIL',error=str(e))
 rows.append(row)
(OUT/'json-deep-validation.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
q=json.load(open(ROOT/'data/encyclopedia/quests/quests_enriched.json'))['quests'];mapping=json.load(open(ROOT/'data/encyclopedia/quests/source_mapping.json'))['quests']
qids=set(map(int,q)); mids=set(map(int,mapping));integrity={'enriched_ids':len(qids),'mapping_ids':len(mids),'missing_mapping_ids':sorted(qids-mids),'missing_enrichment_ids':sorted(mids-qids),'quest_key_id_mismatches':[]}
for key,row in mapping.items():
 if str(row.get('quest_id'))!=key:integrity['quest_key_id_mismatches'].append({'key':key,'quest_id':row.get('quest_id')})
catalog=json.load(open(ROOT/'data/encyclopedia/guides/catalog.json'));integrity['catalog_missing_files']=[r['file'] for r in catalog['guides'] if not (ROOT/'data/encyclopedia/guides'/r['file']).is_file()]
views=json.load(open(ROOT/'data/cartography/map_views.json'))['views'];keys={v['view_key'] for v in views};integrity['map_missing_parent_refs']=[{'view':v['view_key'],'parent':v['parent_view_key']} for v in views if v.get('parent_view_key') and v['parent_view_key'] not in keys];integrity['map_missing_link_targets']=[{'view':v['view_key'],'target':l['target_view_key']} for v in views for l in v.get('links',[]) if l['target_view_key'] not in keys]
integrity['map_duplicate_coords']=[{'view':v['view_key'],'coord':k,'count':c} for v in views for k,c in Counter((m['x'],m['y']) for m in v.get('maps',[])).items() if c>1]
integrity['map_outside_bounds']=[{'view':v['view_key'],'x':m['x'],'y':m['y']} for v in views for m in v.get('maps',[]) if any(v.get('min_'+axis) is not None and m[axis]<v['min_'+axis] or v.get('max_'+axis) is not None and m[axis]>v['max_'+axis] for axis in ('x','y'))]
(OUT/'json-references-validation.json').write_text(json.dumps(integrity,ensure_ascii=False,indent=2))
print('All nodes, communities, candidates and JSON structural/reference checks saved')
