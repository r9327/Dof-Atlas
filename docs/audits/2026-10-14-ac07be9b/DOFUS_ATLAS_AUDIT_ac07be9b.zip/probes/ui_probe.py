import json,sys,tempfile
from pathlib import Path
sys.path.insert(0,'/workspace/Dof-Atlas')
import tests
from PySide6.QtWidgets import QApplication,QLabel,QWidget
from PySide6.QtCore import QTimer
from app.modules.encyclopedia.providers.quest_provider import QuestProvider
from app.quest_catalog import QuestCatalog
from app.modules.encyclopedia.views.encyclopedia_page import EncyclopediaPage
from app.pages.equipment_page import EquipmentPage
from app.ui.theme import atlas_stylesheet
app=QApplication.instance();app.setStyleSheet(atlas_stylesheet())
out=Path('/workspace/audit-atlas/evidence');results={}
with tempfile.TemporaryDirectory() as d:
 root=Path(d)
 page=EncyclopediaPage(lambda _:None,quest_provider=QuestProvider(catalog=QuestCatalog([])),initial_tab='DONJONS',progress_path=root/'q.json',achievement_progress_path=root/'a.json',guide_progress_path=root/'g.json',profile_path=root/'p.json',client_index_path=root/'c.json',owned_items_path=root/'i.json')
 page.resize(1000,700);page.show();app.processEvents()
 for name in ('DONJONS','MONSTRES','ARCHIMONSTRES','AVIS DE RECHERCHE'):
  w=page.ensure_tab_loaded(name)
  results[name]=dict(type=type(w).__name__,object_name=w.objectName(),layout=bool(w.layout()),children=[type(x).__name__ for x in w.findChildren(QWidget)])
 page.grab().save(str(out/'bestiary-empty.png'));page.hide();page.deleteLater();app.processEvents()
 eq=EquipmentPage(lambda _:None);eq.resize(1000,700);eq.show();app.processEvents();eq.grab().save(str(out/'equipment.png'));eq.hide();eq.deleteLater();app.processEvents()
results['note']='Actual Qt widgets; empty supplied catalog; no production Quest/Success data, no gameplay exercised.'
(out/'ui-probe.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(results)
