import json,subprocess,time,os
from pathlib import Path
ROOT=Path('/workspace/Dof-Atlas'); OUT=Path('/workspace/audit-atlas/evidence'); PY='/workspace/audit-atlas/venv/bin/python'
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',QTWEBENGINE_DISABLE_SANDBOX='1')
checks=[
 ('ai-status',['tools.ai_context','status']),('ai-drift',['tools.ai_context','drift']),
 ('ponytail',['tools.atlas_doctor','ponytail','--json']),
 ('change-plan-lots',['tools.atlas_doctor','change-plan','--base-ref','f6deb4a4fc8828ab9fc9372adc8653842303a7e9','--json']),
 ('certify-plan',['tools.atlas_doctor','certify','--base-ref','HEAD','--json']),
 ('dev-check',['tools.atlas_doctor','dev-check','--base-ref','HEAD','--json']),
 ('dev-event',['tools.atlas_doctor','dev-event','--help']),
 ('issues',['tools.atlas_doctor','issues','--json']),('report',['tools.atlas_doctor','report','--json']),
 ('file-audit-entry',['tools.atlas_doctor','file-audit','main.py','app/storage.py','app/preload.py','app/startup_cache_warmup.py','app/ui/network_bridge.py','app/pages/craft_page.py','app/pages/equipment_page.py','app/ui/world_scan_panel.py','--json']),
 ('file-audit-guide',['tools.atlas_doctor','file-audit','app/modules/encyclopedia/views/guides_view.py','app/modules/encyclopedia/views/encyclopedia_page.py','app/modules/encyclopedia/views/memory_bound_encyclopedia_page.py','app/modules/encyclopedia/services/serialized_achievement_progress_service.py','app/modules/encyclopedia/services/guide_progress_service.py','app/modules/encyclopedia/services/quest_progress_service.py','app/quest_catalog.py','app/quest_source_index.py','--json']),
 ('consumer-lazy-widget',['tools.atlas_doctor','consumer-sites','--path','app/modules/encyclopedia/widgets/guide_step_widget.py','--json']),
 ('refactor-profile-preview',['tools.atlas_doctor','refactor-preview','app/core/profile_settings.py','app/storage.py','--action','consolidate','--to','app/core/profile_settings.py','--json']),
 ('isolate-orphan',['tools.atlas_doctor','isolate-triage','--kind','orphan','--limit','10','--json']),
 ('source-impact-storage',['tools.atlas_doctor','source-impact','app/storage.py','app/core/profile_settings.py','app/core/zaap_shortcuts.py','--depth','2','--json']),
 ('code-inspect-entry',['tools.atlas_doctor','code-inspect','main.py','app/storage.py','app/preload.py','app/core/json_store.py','app/core/progress_coordinator.py','app/quest_source_index.py','--entrypoint','main.py','--json']),
]
rows=[]
for name,args in checks:
 start=time.monotonic();cmd=[PY,'-m',*args]
 try:
  r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=180)
  (OUT/(name+'.out')).write_text(r.stdout);(OUT/(name+'.err')).write_text(r.stderr)
  row=dict(name=name,command=cmd,exit=r.returncode,seconds=round(time.monotonic()-start,3))
 except subprocess.TimeoutExpired:row=dict(name=name,command=cmd,exit='TIMEOUT',seconds=180)
 rows.append(row);(OUT/'check-executions.json').write_text(json.dumps(rows,indent=2));print(name,row['exit'],flush=True)
