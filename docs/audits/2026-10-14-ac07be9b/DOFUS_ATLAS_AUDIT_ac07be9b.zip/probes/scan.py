import ast, csv, hashlib, json, subprocess, sys
from collections import defaultdict
from pathlib import Path
ROOT=Path('/workspace/Dof-Atlas'); OUT=Path('/workspace/audit-atlas/evidence')
sys.path.insert(0,str(ROOT))
paths=subprocess.check_output(['git','ls-files','--','*.py'],cwd=ROOT,text=True).splitlines()
files=[]; symbols=[]; dup=defaultdict(list); refs=defaultdict(list); literals=[]; hazards=[]
for p in paths:
 s=(ROOT/p).read_text(encoding='utf-8-sig'); t=ast.parse(s,filename=p)
 fs=[]; imports=[]
 def walk(n,parent=''):
  for c in ast.iter_child_nodes(n):
   if isinstance(c,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
    q=parent+'.'+c.name if parent else c.name
    r=dict(path=p,symbol=q,line=c.lineno,end=c.end_lineno,kind=type(c).__name__)
    if isinstance(c,(ast.FunctionDef,ast.AsyncFunctionDef)):
     r['branches']=sum(isinstance(x,(ast.If,ast.For,ast.While,ast.Try,ast.IfExp,ast.BoolOp,ast.Match)) for x in ast.walk(c))
     r['calls']=[ast.unparse(x.func) for x in ast.walk(c) if isinstance(x,ast.Call)]
     if sum(1 for _ in ast.walk(c))>20:
      dup[hashlib.sha256(ast.dump(ast.Module(body=c.body,type_ignores=[]),include_attributes=False).encode()).hexdigest()].append({k:r[k] for k in ('path','symbol','line','end')})
    symbols.append(r); fs.append(q); walk(c,q)
   else: walk(c,parent)
 walk(t)
 for n in ast.walk(t):
  if isinstance(n,(ast.Import,ast.ImportFrom)): imports.append(dict(line=n.lineno,text=ast.unparse(n)))
  if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Load): refs[n.id].append((p,n.lineno))
  if isinstance(n,ast.Attribute) and isinstance(n.ctx,ast.Load): refs[n.attr].append((p,n.lineno))
  if isinstance(n,ast.Constant) and isinstance(n.value,str) and len(n.value)<300 and '.json' in n.value: literals.append(dict(path=p,line=n.lineno,value=n.value))
  if isinstance(n,ast.ExceptHandler) and (n.type is None or ast.unparse(n.type) in ('Exception','BaseException')): hazards.append(dict(path=p,line=n.lineno,type=ast.unparse(n.type) if n.type else 'bare',body=ast.unparse(ast.Module(body=n.body,type_ignores=[]))))
 files.append(dict(path=p,sha256=hashlib.sha256(s.encode()).hexdigest(),lines=len(s.splitlines()),symbols=fs,imports=imports,review='AST_FULL_SOURCE; semantic review by subsystem, not all runtime paths'))
for name,data in [('python-files',files),('python-symbols',symbols),('exact-duplicates',[v for v in dup.values() if len(v)>1]),('json-literals',literals),('exception-candidates',hazards),('name-references',refs)]:
 (OUT/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
from tools.atlas_doctor_lib.deep_intelligence import scan_sources
for i in range(0,len(paths),20):
 (OUT/f'source-scan-{i//20:02}.json').write_text(json.dumps(scan_sources(ROOT,paths[i:i+20]),ensure_ascii=False,indent=2))
print('Parsed',len(files),'files and',len(symbols),'definitions; full inventory saved')
